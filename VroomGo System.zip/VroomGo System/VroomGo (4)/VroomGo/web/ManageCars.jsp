<%-- 
    Document   : ManageCars
    Created on : Jun 30, 2026, 9:59:21 AM
    Author     : USER
--%>

<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="java.util.*, rent.bean.*" %>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Cars - VroomGo</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<%
    HttpSession adminSession = request.getSession(false);
    AdminBean admin = null;
    if (adminSession != null) {
        admin = (AdminBean) adminSession.getAttribute("loggedAdmin");
    }
    if (admin == null) {
        response.sendRedirect("AdminLogin.jsp");
        return;
    }
%>

<div class="navbar">
    <a href="AdminDashboardServlet" class="navbar-logo">
        <img src="images/logovroomgo_2.png" alt="VroomGo Logo" />
    </a>
    <div class="navbar-right">
        <span>Hello, <%= admin.getAdminName() %></span>
        <a href="AdminLogoutServlet" class="logout">Logout</a>
    </div>
</div>

<div class="admin-layout">
    
    <div class="sidebar">
        <a href="AdminDashboardServlet" class="sidebar-link">Dashboard</a>
        <a href="ManageOwnerServlet" class="sidebar-link">Manage Owners</a>
        <a href="ManageTenantServlet" class="sidebar-link">Manage Tenants</a>
        <a href="ManageCarsServlet" class="sidebar-link active">Manage Cars</a>
        <a href="ManageRentDetailsServlet" class="sidebar-link">Rent Details</a>
        <a href="ManageTransactionServlet" class="sidebar-link">Transactions</a>
        <a href="ManageReportsServlet" class="sidebar-link">Reports</a>
        <a href="ManageWithdrawServlet" class="sidebar-link">Owner Withdrawal</a>
        <a href="AdminAddAdminServlet" class="sidebar-link">Add Admin</a>
    </div>

    <div class="admin-content">
        <div class="page-title">Manage Cars</div>

        <% String updated     = request.getParameter("updated");
           String deleted     = request.getParameter("deleted");
           String deleteError = request.getParameter("deleteError");
        %>
        <% if ("true".equals(updated))     { %><div class="alert alert-success">Car updated successfully!</div><% } %>
        <% if ("true".equals(deleted))     { %><div class="alert alert-success">Car deleted successfully!</div><% } %>
        <% if ("true".equals(deleteError)) { %><div class="alert alert-error">Cannot delete — car is currently rented.</div><% } %>
        
        <%
            List<CarBean> carList = (List<CarBean>) request.getAttribute("carList");
            if (carList == null || carList.isEmpty()) {
        %>
            <div class="no-data"><p>No cars found in the system.</p></div>
        <% } else { %>
        <table>
            <tr>
                <th>Car ID</th>
                <th>Owner</th>
                <th>Plate Number</th>
                <th>Model</th>
                <th>Colour</th>
                <th>Rate (RM/day)</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
            <%
                for (CarBean car : carList) {
                    String badgeClass = "badge-other";
                    if ("Available".equals(car.getStatus())) badgeClass = "badge-available";
                    else if ("Rented".equals(car.getStatus())) badgeClass = "badge-rented";
            %>
            <tr>
                <td><%= car.getCarId() %></td>
                <td><%= car.getOwnerName() %></td>
                <td><%= car.getPlateNumber() %></td>
                <td><%= car.getCarModel() %></td>
                <td><%= car.getCarColour() %></td>
                <td>RM <%= String.format("%.2f", car.getRentalRate()) %></td>
                <td><span class="badge <%= badgeClass %>"><%= car.getStatus() %></span></td>
                <td>
                    <a href="#" onclick="openEditModal('<%= car.getCarId() %>','<%= car.getPlateNumber() %>','<%= car.getCarModel() %>','<%= car.getCarColour() %>','<%= car.getRentalRate() %>','<%= car.getStatus() %>'); return false;" class="btn-edit">Edit</a>
                    &nbsp;
                    <a href="ManageCarsServlet?action=delete&carId=<%= car.getCarId() %>"
                       class="btn-delete"
                       onclick="return confirm('Delete this car?')">Delete</a>
                </td>
            </tr>
            <% } %>
        </table>
        <% } %>
    </div>
</div>

<div id="editModal" class="modal-overlay" style="display:none;">
    <div class="modal-box">
        <h3>Edit Car</h3>
        <form action="ManageCarsServlet" method="post">
            <input type="hidden" name="carId" id="modalCarId"/>
            <div class="form-group">
                <label>Plate Number</label>
                <input type="text" name="plateNumber" id="modalPlateNumber" required/>
            </div>
            <div class="form-group">
                <label>Car Model</label>
                <input type="text" name="carModel" id="modalCarModel" required/>
            </div>
            <div class="form-group">
                <label>Car Colour</label>
                <input type="text" name="carColour" id="modalCarColour" required/>
            </div>
            <div class="form-group">
                <label>Rental Rate (RM/day)</label>
                <input type="number" name="rentalRate" id="modalRentalRate" step="0.01" required/>
            </div>
            <div class="form-group">
                <label>Status</label>
                <select name="status" id="modalStatus">
                    <option value="Available">Available</option>
                    <option value="Rented">Rented</option>
                    <option value="Inactive">Inactive</option>
                </select>
            </div>
            <div class="form-actions">
                <button type="button" class="btn-secondary" onclick="closeEditModal()">Cancel</button>
                <button type="submit" class="btn">Save Changes</button>
            </div>
        </form>
    </div>
</div>

<script>
function openEditModal(carId, plateNumber, carModel, carColour, rentalRate, status) {
    document.getElementById('modalCarId').value = carId;
    document.getElementById('modalPlateNumber').value = plateNumber;
    document.getElementById('modalCarModel').value = carModel;
    document.getElementById('modalCarColour').value = carColour;
    document.getElementById('modalRentalRate').value = rentalRate;
    document.getElementById('modalStatus').value = status;
    document.getElementById('editModal').style.display = 'flex';
}
function closeEditModal() {
    document.getElementById('editModal').style.display = 'none';
}
</script>
</body>
</html>
