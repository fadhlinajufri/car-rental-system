<%-- 
    Document   : OwnerDashboard
    Created on : Jun 26, 2026, 4:34:05 PM
    Author     : USER
--%>
<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="java.util.*, rent.bean.*" %>
<!DOCTYPE html>
<html>
<head>
    <title>Owner Dashboard - VroomGo</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<%
    HttpSession ownerSession = request.getSession(false);
    if (ownerSession == null || ownerSession.getAttribute("loggedOwner") == null) {
        response.sendRedirect("OwnerLogin.jsp");
        return;
    }
    OwnerBean owner = (OwnerBean) ownerSession.getAttribute("loggedOwner");
%>


<div class="navbar">
    <a href="OwnerDashboardServlet" class="navbar-logo">
        <img src="images/logovroomgo_2.png" alt="VroomGo Logo" />
    </a>
    <div class="navbar-right">
        <span>Hello, <%= owner.getOwnerName() %></span>
        <a href="OwnerEditProfileServlet">Edit Profile</a>
        <a href="OwnerLogoutServlet" class="logout">Logout</a>
    </div>
</div>

        
<div class="container">

    <div class="page-title">Dashboard</div>
    <%
    String added= request.getParameter("added");
    String updated = request.getParameter("updated");
    String deleted = request.getParameter("deleted");
    String deleteError = request.getParameter("deleteError");
%>

<% if ("true".equals(added)){ %><div class="alert alert-success">Car added successfully!</div><% } %>
<% if ("true".equals(updated)){ %><div class="alert alert-success">Car updated successfully!</div><% } %>
<% if ("true".equals(deleted)){ %><div class="alert alert-success">Car deleted successfully!</div><% } %>
<% if ("true".equals(deleteError)){ %><div class="alert alert-error">Cannot delete — car is currently rented or an error occurred.</div><% } %>
<% if ("true".equals(request.getParameter("profileUpdated"))) { %>
    <div class="alert alert-success">Profile updated successfully!</div>
<% } %>
<% if ("true".equals(request.getParameter("withdrawRequested"))) { %>
    <div class="alert alert-success">Withdrawal request submitted successfully!</div>
<% } %>
<% if (request.getParameter("withdrawError") != null) { %>
    <div class="alert alert-error"><%= request.getParameter("withdrawError") %></div>
<% } %>
    
    <div class="stats">
        <div class="stat-card">
            <div class="number"><%= request.getAttribute("totalCars") != null ? request.getAttribute("totalCars") : 0 %></div>
            <div class="label">Total Cars</div>
        </div>
        <div class="stat-card">
            <div class="number"><%= request.getAttribute("availableCars") != null ? request.getAttribute("availableCars") : 0 %></div>
            <div class="label">Available</div>
        </div>
        <div class="stat-card">
            <div class="number"><%= request.getAttribute("rentedCars") != null ? request.getAttribute("rentedCars") : 0 %></div>
            <div class="label">Rented Out</div>
        </div>
    </div>

    <div class="revenue-card">
        <div class="revenue-label">My Earnings (after service charge)</div>
        <div class="revenue-amount">
            RM <%= String.format("%.2f", request.getAttribute("totalEarnings") != null ? (Double) request.getAttribute("totalEarnings") : 0.0) %>
        </div>
        <div style="margin-top:16px;">
            <a href="OwnerWithdrawServlet" class="btn">Withdraw</a>
        </div>
    </div>

            
            
    <div class="section-header" style="margin-top:32px;">
        <h2>My Cars</h2>
        <a href="OwnerAddCarServlet" class="btn">+ Add New Car</a>
    </div>

    <%
        List<CarBean> carList = (List<CarBean>) request.getAttribute("carList");
        if (carList == null || carList.isEmpty()) {
    %>
        <div class="no-data">
            <p>You have no cars listed yet.</p>
            <a href="OwnerAddCar.jsp" class="btn">Add Your First Car</a>
        </div>
    <% } else { %>
        <table>
            <tr>
                <th>Car ID</th>
                <th>Plate Number</th>
                <th>Model</th>
                <th>Colour</th>
                <th>Rate (RM/day)</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
            <%
                for (CarBean car : carList) {
                    String badgeClass = "badge-other";
                    if ("Available".equals(car.getStatus())) badgeClass = "badge-available";
                    else if ("Rented".equals(car.getStatus())) badgeClass = "badge-rented";
            %>
            <tr>
                <td><%= car.getCarId() %></td>
                <td><%= car.getPlateNumber() %></td>
                <td><%= car.getCarModel() %></td>
                <td><%= car.getCarColour() %></td>
                <td>RM <%= String.format("%.2f", car.getRentalRate()) %></td>
                <td><span class="badge <%= badgeClass %>"><%= car.getStatus() %></span></td>
                <td>
                    <a href="OwnerEditCarServlet?carId=<%= car.getCarId() %>" class="btn-edit">Edit</a>
                    &nbsp;
                    <a href="OwnerDeleteCarServlet?carId=<%= car.getCarId() %>"
                       class="btn-delete"
                       onclick="return confirm('Are you sure you want to delete this car?')">Delete</a>
                </td>
            </tr>
            <% } %>
        </table>
    <% } %>
    
           
</div>
</body>
</html>