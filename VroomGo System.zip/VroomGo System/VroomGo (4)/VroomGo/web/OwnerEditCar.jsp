<%-- 
    Document   : OwnerEditCar
    Created on : Jun 26, 2026, 5:03:00 PM
    Author     : USER
--%>

<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="rent.bean.*" %>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Car - VroomGo</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<%
    HttpSession ownerSession = request.getSession(false);
    if (ownerSession == null || ownerSession.getAttribute("loggedOwner") == null) {
        response.sendRedirect("OwnerLogin.jsp");
        return;
    }
    OwnerBean owner = (OwnerBean) ownerSession.getAttribute("loggedOwner");
    CarBean car = (CarBean) request.getAttribute("car");
    if (car == null) {
        response.sendRedirect("OwnerDashboardServlet");
        return;
    }
%>

<div class="navbar">
    <a href="OwnerDashboardServlet" class="navbar-logo">
        <img src="images/logovroomgo_2.png" alt="VroomGo Logo" />
    </a>
    <div class="navbar-right">
        <span>Hello, <%= owner.getOwnerName() %></span>
        <a href="OwnerEditProfileServlet">Edit Profile</a>
        <a href="OwnerLogoutServlet" class="logout">Logout</a>
    </div>
</div>

<div class="container">
    <div class="page-title">Edit Car</div>
    
    <% String error = (String) request.getAttribute("error");
       if (error != null) { %>
        <div class="alert alert-error"><%= error %></div>
    <% } %>
    
    <div class="form-card">
        <form action="OwnerEditCarServlet" method="post" enctype="multipart/form-data">
            
            <input type="hidden" name="carId"    value="<%= car.getCarId() %>"/>
            <input type="hidden" name="oldImage" value="<%= car.getCarImage() %>"/>
            <div class="form-group">
    Car Image
    <input type="file" name="carImage" accept="image/*" class="file-input"/>
    <small class="input-hint">Leave empty to keep current image.</small>
</div>
            <div class="form-row">
                <div class="form-group">
                    Plate Number
                    <input type="text" name="plateNumber" required value="<%= car.getPlateNumber() %>"/>
                </div>
                <div class="form-group">
                    <label>Car Model</label>
                    <input type="text" name="carModel" required value="<%= car.getCarModel() %>"/>
                </div>
            </div>
                
            <div class="form-row">
                <div class="form-group">
                    Car Colour
                    <input type="text" name="carColour" required value="<%= car.getCarColour() %>"/>
                </div>
                <div class="form-group">
                    Rental Rate (RM/day)
                    <input type="number" name="rentalRate" required
                           value="<%= car.getRentalRate() %>" min="1" step="0.01"/>
                </div>
            </div>
                
            <div class="form-row">
                <div class="form-group">
                    Status
                    <select name="status">
                        <option value="Available" <%= "Available".equals(car.getStatus()) ? "selected" : "" %>>Available</option>
                        <option value="Rented"    <%= "Rented".equals(car.getStatus())    ? "selected" : "" %>>Rented</option>
                        <option value="Inactive"  <%= "Inactive".equals(car.getStatus())  ? "selected" : "" %>>Inactive</option>
                    </select>
                </div>
                <div class="form-group">
    Car Image URL
    <input type="text" name="carImage" value="<%= car.getCarImage() != null && !car.getCarImage().equals("default.png") ? car.getCarImage() : "" %>"
           placeholder="e.g. https://example.com/car.jpg or leave empty"/>
    <small class="input-hint">Paste a new image URL, or leave empty to keep current.</small>
</div>
            </div>
                    
            <% if (car.getCarImage() != null && !car.getCarImage().isEmpty() && !"default.png".equals(car.getCarImage())) { %>
            <div class="form-group">
                Current Image
                <img src="CarImagesServlet?file=<%= car.getCarImage() %>"
                     alt="Car Image"
                     style="height:120px; border-radius:8px; border:1px solid #eee; object-fit:cover;"/>
            </div>
            <% } %>
            
            <div class="form-actions">
                <a href="OwnerDashboardServlet" class="btn-secondary">Cancel</a>
                <button type="submit" class="btn">Save Changes</button>
            </div>

        </form>
    </div>
</div>
</body>
</html>
