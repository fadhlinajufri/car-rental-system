<%-- 
    Document   : TenantReceipt
    Created on : Jul 14, 2026, 1:23:36 PM
    Author     : user
--%>

<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="rent.bean.TenantBean" %>
<!DOCTYPE html>
<html>
<head>
    <title>Receipt - VroomGo</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<%
    HttpSession tenantSession = request.getSession(false);
    TenantBean tenant = null;
    if (tenantSession != null) {
        tenant = (TenantBean) tenantSession.getAttribute("loggedTenant");
    }
    if (tenant == null) {
        response.sendRedirect("TenantLogin.jsp");
        return;
    }
%>

<div class="navbar">
    <a href="TenantDashboardServlet" class="navbar-logo">
        <img src="images/logovroomgo_2.png" alt="VroomGo Logo" />
    </a>
    <div class="navbar-right">
        <span>Hello, <%= tenant.getTenantName() %></span>
        <a href="TenantLogoutServlet" class="logout">Logout</a>
    </div>
</div>

<div class="container">
    <div class="page-title">Payment Receipt</div>

    <% String error = (String) request.getAttribute("error");
       if (error != null) { %>
        <div class="alert alert-error"><%= error %></div>
    <% } else { %>

        <button class="btn-print" onclick="window.print()">Print Receipt</button>

        <div class="form-card" id="reportContent">
            <div class="alert alert-success">Payment successful! Thank you for booking with VroomGo.</div>

            <div class="payment-summary">
                <div class="summary-row">
                    <span>Transaction ID</span>
                    <strong><%= request.getAttribute("transactionId") %></strong>
                </div>
                <div class="summary-row">
                    <span>Transaction Date</span>
                    <strong><%= request.getAttribute("transactionDate") %></strong>
                </div>
                <div class="summary-row">
                    <span>Booking ID</span>
                    <strong><%= request.getAttribute("rentId") %></strong>
                </div>
                <div class="summary-row">
                    <span>Car</span>
                    <strong><%= request.getAttribute("carModel") %> (<%= request.getAttribute("plateNumber") %>)</strong>
                </div>
                <div class="summary-row">
                    <span>Rent Date</span>
                    <strong><%= request.getAttribute("rentDate") %></strong>
                </div>
                <div class="summary-row">
                    <span>Return Date</span>
                    <strong><%= request.getAttribute("returnDate") %></strong>
                </div>
                <div class="summary-row">
                    <span>Payment Method</span>
                    <strong><%= request.getAttribute("paymentMethod") %></strong>
                </div>
                <div class="summary-row">
                    <span>Status</span>
                    <strong><%= request.getAttribute("transactionStatus") %></strong>
                </div>
                <div class="summary-row">
                    <span>Total Amount</span>
                    <strong class="payment-amount">RM <%= String.format("%.2f", (Double) request.getAttribute("amount")) %></strong>
                </div>
            </div>
        </div>

        <div class="form-actions" style="max-width:700px;">
            <a href="TenantDashboardServlet?booked=true" class="btn">Back to Dashboard</a>
        </div>

    <% } %>
</div>
</body>
</html>
