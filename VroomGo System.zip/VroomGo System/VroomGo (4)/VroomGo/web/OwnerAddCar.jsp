<%-- 
    Document   : OwnerAddCar
    Created on : Jun 26, 2026, 4:57:09 PM
    Author     : USER
--%>


<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="rent.bean.OwnerBean" %>
<!DOCTYPE html>
<html>
<head>
    <title>Add Car - VroomGo</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<%
    HttpSession ownerSession = request.getSession(false);
    OwnerBean owner = null;
    if (ownerSession != null) {
        owner = (OwnerBean) ownerSession.getAttribute("loggedOwner");
    }
    if (owner == null) {
        response.sendRedirect("OwnerLogin.jsp");
        return;
    }
%>

<div class="navbar">
    <a href="OwnerDashboardServlet" class="navbar-logo">
        <img src="images/logovroomgo_2.png" alt="VroomGo Logo" />
    </a>
    <div class="navbar-right">
        <span>Hello, <%= owner.getOwnerName() %></span>
        <a href="OwnerEditProfileServlet">Edit Profile</a>
        <a href="OwnerLogoutServlet" class="logout">Logout</a>
    </div>
</div>

<div class="container">
    <div class="page-title">Add New Car</div>
    
    <% String error = (String) request.getAttribute("error");
       if (error != null) { %>
        <div class="alert alert-error"><%= error %></div>
    <% } %>
    
    <div class="form-card">
        <form action="OwnerAddCarServlet" method="post" enctype="multipart/form-data">
            <div class="form-row">
                <div class="form-group">
                    Plate Number
                    <input type="text" name="plateNumber" required placeholder="e.g. WXX 1234"/>
                </div>
                <div class="form-group">
                    Car Model
                    <input type="text" name="carModel" required placeholder="e.g. Toyota Vios"/>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    Car Colour
                    <input type="text" name="carColour" required placeholder="e.g. White"/>
                </div>
                <div class="form-group">
                    Rental Rate (RM/day)
                    <input type="number" name="rentalRate" required placeholder="e.g. 150" min="1" step="0.01"/>
                </div>
            </div>
            
            
            <div class="form-group">
                Car Image
                <input type="file" name="carImage" accept="image/*" class="file-input"/>
                <small class="input-hint">Accepted formats: JPG, PNG. Max 2MB.</small>
            </div>
            
            
            <div class="form-actions">
                <a href="OwnerDashboardServlet" class="btn-secondary">Cancel</a>
                <button type="submit" class="btn">Add Car</button>
            </div>

        </form>
    </div>
</div>
</body>
</html>