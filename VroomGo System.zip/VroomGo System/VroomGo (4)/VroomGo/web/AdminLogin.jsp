<%-- 
    Document   : AdminLogin
    Created on : Jun 30, 2026, 9:51:27 AM
    Author     : USER
--%>

<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Login - VroomGo</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="form-page">
    <div class="form-wrapper">

        <img src="images/logovroomgo_2.png" alt="VroomGo Logo" class="form-logo" />
        <h2>Admin <span>Login</span></h2>

        <% String error = (String) request.getAttribute("error");
           if (error != null) { %>
            <div class="alert alert-error"><%= error %></div>
        <% } %>

        <form action="AdminLoginServlet" method="post">
            <div class="form-group">
                Email
                <input type="email" name="adminEmail" required placeholder="admin@vroomgo.com"/>
            </div>
            <div class="form-group">
                Password
                <input type="password" name="adminPassword" required placeholder="••••••••"/>
            </div>
            <input type="submit" value="Login" class="form-submit"/>
        </form>
    </div>
</div>
</body>
</html>