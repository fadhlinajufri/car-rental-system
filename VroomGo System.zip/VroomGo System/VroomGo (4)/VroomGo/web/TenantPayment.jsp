<%-- 
    Document   : TenantPayment
    Created on : Jun 29, 2026, 5:36:12 PM
    Author     : USER
--%>

<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="rent.bean.TenantBean" %>
<!DOCTYPE html>
<html>
<head>
    <title>Payment - VroomGo</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .bank-option {
            display: flex;
            align-items: center;
            gap: 8px;
            border: 1px solid #ccc;
            border-radius: 6px;
            padding: 10px 16px;
            cursor: pointer;
        }
        .bank-option.selected {
            border-color: #007bff;
            background: #f0f7ff;
        }
        #cardFields input, #cardFields label {
            display: block;
            width: 100%;
        }
    </style>
</head>
<body>

<%
    HttpSession tenantSession = request.getSession(false);
    TenantBean tenant = null;
    if (tenantSession != null) {
        tenant = (TenantBean) tenantSession.getAttribute("loggedTenant");
    }
    if (tenant == null) {
        response.sendRedirect("TenantLogin.jsp");
        return;
    }
    String rentId  = request.getParameter("rentId");
    String payment = request.getParameter("payment");
%>

<div class="navbar">
    <a href="TenantDashboardServlet" class="navbar-logo">
        <img src="images/logovroomgo_2.png" alt="VroomGo Logo" />
    </a>
    <div class="navbar-right">
        <span>Hello, <%= tenant.getTenantName() %></span>
        <a href="TenantLogoutServlet" class="logout">Logout</a>
    </div>
</div>
<div class="container">
    <div class="page-title">Payment</div>
    <% String error = (String) request.getAttribute("error");
       if (error != null) { %>
        <div class="alert alert-error"><%= error %></div>
    <% } %>
    
    <div class="form-card">
        <div class="payment-summary">
            <div class="summary-row">
                <span>Booking ID</span>
                <strong><%= rentId %></strong>
            </div>
            <div class="summary-row">
                <span>Total Amount</span>
                <strong class="payment-amount">RM <%= String.format("%.2f", Double.parseDouble(payment)) %></strong>
            </div>
        </div>
            
            
    <form action="TenantPaymentServlet" method="post" id="paymentForm">
        <input type="hidden" name="rentId"  value="<%= rentId %>"/>
        <input type="hidden" name="payment" value="<%= payment %>"/>

    <div class="form-group" style="margin-top:24px;">
        <label>Payment Method</label>
        <select name="paymentMethod" id="paymentMethod" required onchange="togglePaymentFields()">
            <option value="">-- Select Payment Method --</option>
            <option value="Online Banking">Online Banking</option>
            <option value="Credit Card">Credit Card</option>
            <option value="Debit Card">Debit Card</option>
            <option value="Cash">Cash</option>
            <option value="E-Wallet">E-Wallet</option>
        </select>
    </div>

    <!-- Credit / Debit Card fields -->
    <div id="cardFields" class="form-group" style="display:none; margin-top:16px;">
        <label>Card Number</label>
        <input type="text" name="cardNumber" id="cardNumber" maxlength="19"
               placeholder="1234 5678 9012 3456" pattern="[0-9\s]{13,19}">

        <label style="margin-top:12px;">Name on Card</label>
        <input type="text" name="cardName" id="cardName" placeholder="e.g. AHMAD BIN ALI">

        <div style="display:flex; gap:12px; margin-top:12px;">
            <div style="flex:1;">
                <label>Expiry Date</label>
                <input type="text" name="cardExpiry" id="cardExpiry" placeholder="MM/YY" maxlength="5">
            </div>
            <div style="flex:1;">
                <label>CVV</label>
                <input type="text" name="cardCvv" id="cardCvv" placeholder="123" maxlength="4">
            </div>
        </div>
    </div>

    <!-- Online Banking fields -->
    <div id="bankFields" class="form-group" style="display:none; margin-top:16px;">
        <label>Select Bank</label>
        <div class="bank-options" style="display:flex; gap:12px; margin-top:8px; flex-wrap:wrap;">
            <label class="bank-option">
                <input type="radio" name="bankName" value="Maybank" id="bankMaybank"> Maybank
            </label>
            <label class="bank-option">
                <input type="radio" name="bankName" value="Bank Islam" id="bankIslam"> Bank Islam
            </label>
            <label class="bank-option">
                <input type="radio" name="bankName" value="RHB" id="bankRhb"> RHB
            </label>
        </div>
    </div>

    <div class="form-actions">
        <button type="submit"
                formaction="TenantCancelBookingServlet"
                formnovalidate
                class="btn-secondary"
                onclick="return confirm('Cancel this booking? The car will be released.');">
            Cancel
        </button>

        <button type="submit" class="btn">Pay Now</button>
    </div>
    </form>
    </div>
</div>

<script>
function togglePaymentFields() {
    var method = document.getElementById("paymentMethod").value;
    var cardFields = document.getElementById("cardFields");
    var bankFields = document.getElementById("bankFields");

    var cardInputs = ["cardNumber", "cardName", "cardExpiry", "cardCvv"];
    var bankRadios = ["bankMaybank", "bankIslam", "bankRhb"];

    // Hide everything and clear "required" first
    cardFields.style.display = "none";
    bankFields.style.display = "none";
    cardInputs.forEach(function(id) {
        document.getElementById(id).required = false;
    });
    bankRadios.forEach(function(id) {
        document.getElementById(id).required = false;
    });

    if (method === "Credit Card" || method === "Debit Card") {
        cardFields.style.display = "block";
        cardInputs.forEach(function(id) {
            document.getElementById(id).required = true;
        });
    } else if (method === "Online Banking") {
        bankFields.style.display = "block";
        bankRadios.forEach(function(id) {
            document.getElementById(id).required = true;
        });
    }
}

// Auto-format card number with spaces every 4 digits
document.getElementById("cardNumber").addEventListener("input", function(e) {
    var v = e.target.value.replace(/\s+/g, "").replace(/[^0-9]/g, "");
    e.target.value = v.replace(/(.{4})/g, "$1 ").trim();
});

// Auto-format expiry as MM/YY
document.getElementById("cardExpiry").addEventListener("input", function(e) {
    var v = e.target.value.replace(/[^0-9]/g, "");
    if (v.length > 2) {
        v = v.slice(0, 2) + "/" + v.slice(2, 4);
    }
    e.target.value = v;
});

// CVV numeric only
document.getElementById("cardCvv").addEventListener("input", function(e) {
    e.target.value = e.target.value.replace(/[^0-9]/g, "");
});

// Run once on page load in case of back-navigation with a value already selected
togglePaymentFields();
</script>

</body>
</html>
