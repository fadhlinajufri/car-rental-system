<%-- 
    Document   : OwnerWithdraw
    Created on : Jul 15, 2026
    Author     : USER
--%>
<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="java.util.*, rent.bean.*" %>
<!DOCTYPE html>
<html>
<head>
    <title>Withdraw Earnings - VroomGo</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<%
    HttpSession ownerSession = request.getSession(false);
    if (ownerSession == null || ownerSession.getAttribute("loggedOwner") == null) {
        response.sendRedirect("OwnerLogin.jsp");
        return;
    }
    OwnerBean owner = (OwnerBean) ownerSession.getAttribute("loggedOwner");
    Double availableBalance = (Double) request.getAttribute("availableBalance");
    if (availableBalance == null) availableBalance = 0.0;
%>

<div class="navbar">
    <a href="OwnerDashboardServlet" class="navbar-logo">
        <img src="images/logovroomgo_2.png" alt="VroomGo Logo" />
    </a>
    <div class="navbar-right">
        <span>Hello, <%= owner.getOwnerName() %></span>
        <a href="OwnerEditProfileServlet">Edit Profile</a>
        <a href="OwnerLogoutServlet" class="logout">Logout</a>
    </div>
</div>

<div class="container">

    <div class="page-title">Withdraw Earnings</div>

    <%
        String withdrawError = (String) request.getAttribute("withdrawError");
        if (withdrawError != null) {
    %>
        <div class="alert alert-error"><%= withdrawError %></div>
    <% } %>

    <div class="revenue-card">
        <div class="revenue-label">Available Balance</div>
        <div class="revenue-amount">RM <%= String.format("%.2f", availableBalance) %></div>
    </div>

    <div class="form-card" style="margin-top:24px;">
        <h2 style="margin-bottom:20px;">Request a Withdrawal</h2>

        <% boolean hasBankDetails = owner.getBankName() != null && !owner.getBankName().trim().isEmpty()
                && owner.getBankAccNumber() != null && !owner.getBankAccNumber().trim().isEmpty(); %>

        <% if (!hasBankDetails) { %>
            <div class="alert alert-error">
                You must add your bank details before requesting a withdrawal.
                <a href="OwnerEditProfileServlet">Add bank details</a>
            </div>
        <% } else { %>
            <div class="form-group">
                <label>Bank</label>
                <input type="text" value="<%= owner.getBankName() %>" disabled>
            </div>
            <div class="form-group">
                <label>Account Number</label>
                <input type="text" value="<%= owner.getBankAccNumber() %>" disabled>
            </div>

            <form action="OwnerRequestWithdrawServlet" method="post">
                <div class="form-group">
                    <label>Amount (RM)</label>
                    <input type="number" name="amount" step="0.01" min="0.01"
                           max="<%= availableBalance %>" required>
                    <span class="input-hint">Maximum: RM <%= String.format("%.2f", availableBalance) %></span>
                </div>
                <div class="form-actions">
                    <a href="OwnerDashboardServlet" class="btn-secondary">Cancel</a>
                    <button type="submit" class="btn" <%= availableBalance <= 0 ? "disabled" : "" %>>
                        Submit Request
                    </button>
                </div>
            </form>
        <% } %>
    </div>

    <div class="section-header" style="margin-top:32px;">
        <h2>Withdrawal History</h2>
    </div>

    <%
        List<WithdrawalBean> withdrawHistory = (List<WithdrawalBean>) request.getAttribute("withdrawHistory");
        if (withdrawHistory == null || withdrawHistory.isEmpty()) {
    %>
        <div class="no-data">
            <p>No withdrawal requests yet.</p>
        </div>
    <% } else { %>
        <table>
            <tr>
                <th>Request ID</th>
                <th>Amount (RM)</th>
                <th>Status</th>
                <th>Requested On</th>
            </tr>
            <%
                for (WithdrawalBean w : withdrawHistory) {
                    String badgeClass = "badge-other";
                    String status = w.getStatus();
                    if ("Approved".equalsIgnoreCase(status) || "Completed".equalsIgnoreCase(status)) badgeClass = "badge-available";
                    else if ("Pending".equalsIgnoreCase(status)) badgeClass = "badge-rented";
                    else if ("Rejected".equalsIgnoreCase(status)) badgeClass = "badge-other";
            %>
            <tr>
                <td><%= w.getWithdrawId() %></td>
                <td>RM <%= String.format("%.2f", w.getAmount()) %></td>
                <td><span class="badge <%= badgeClass %>"><%= status %></span></td>
                <td><%= w.getRequestDate() %></td>
            </tr>
            <% } %>
        </table>
    <% } %>

</div>
</body>
</html>