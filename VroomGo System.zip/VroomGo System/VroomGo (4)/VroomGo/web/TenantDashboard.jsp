<%-- 
    Document   : TenantDashboard
    Created on : Jun 29, 2026, 5:32:00 PM
    Author     : USER
--%>


<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="java.util.*, rent.bean.*" %>
<!DOCTYPE html>
<html>
<head>
    <title>Tenant Dashboard - VroomGo</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<%
    HttpSession tenantSession = request.getSession(false);
    TenantBean tenant = null;
    if (tenantSession != null) {
        tenant = (TenantBean) tenantSession.getAttribute("loggedTenant");
    }
    if (tenant == null) {
        response.sendRedirect("TenantLogin.jsp");
        return;
    }
%>

<div class="navbar">
    <a href="TenantDashboardServlet" class="navbar-logo">
        <img src="images/logovroomgo_2.png" alt="VroomGo Logo" />
    </a>
    <div class="navbar-right">
        <span>Hello, <%= tenant.getTenantName() %></span>
         <a href="TenantEditProfileServlet">Edit Profile</a>
        <a href="TenantLogoutServlet" class="logout">Logout</a>
    </div>
</div>

<div class="container">
    <div class="page-title">Tenant Dashboard</div>
    
    <% String error = (String) request.getAttribute("error");
       if (error != null) { %>
        <div class="alert alert-error"><%= error %></div>
    <% } %>
    <% if ("true".equals(request.getParameter("booked"))) { %>
        <div class="alert alert-success">Booking confirmed! Check "My Active Bookings" below.</div>
    <% } %>
    <% if ("true".equals(request.getParameter("returned"))) { %>
        <div class="alert alert-success">Car returned successfully!</div>
    <% } %>
    
    <div class="section-header">
        <h2>My Active Bookings</h2>
         <a href="TenantBookingHistoryServlet" class="btn-secondary">Booking History</a>
    </div>
    <%
        List<RentDetailsBean> bookingList = (List<RentDetailsBean>) request.getAttribute("bookingList");
        if (bookingList == null || bookingList.isEmpty()) {
    %>
        <div class="no-data" style="margin-bottom:32px;">
            <p>You have no active bookings.</p>
        </div>
    <% } else { %>
        <table style="margin-bottom:32px;">
            <tr>
                <th>Rent ID</th>
                <th>Car</th>
                <th>Rent Date</th>
                <th>Return Date</th>
                <th>Payment</th>
                <th>Action</th>
            </tr>
            <% for (RentDetailsBean rent : bookingList) { %>
            <tr>
                <td><%= rent.getRentId() %></td>
                <td><%= rent.getCarModel() %> (<%= rent.getPlateNum() %>)</td>
                <td><%= rent.getRentDate() %></td>
                <td><%= rent.getReturnDate() %></td>
                <td>RM <%= String.format("%.2f", rent.getPayment()) %></td>
                <td>
                    <a href="TenantReturnCarServlet?rentId=<%= rent.getRentId() %>"
                       class="btn-edit"
                       onclick="return confirm('Confirm you are returning this car?')">Return Car</a>
                </td>
            </tr>
            <% } %>
        </table>
    <% } %>
    <div class="section-header">
        <h2>Available Cars</h2>
    </div>
    
    <%
        List<CarBean> carList = (List<CarBean>) request.getAttribute("carList");
        if (carList == null || carList.isEmpty()) {
    %>
        <div class="no-data">
            <p>No cars available at the moment. Please check back later.</p>
        </div>
    <% } else { %>
        <div class="car-grid">
            <% for (CarBean car : carList) { %>
            <div class="car-card">
                <img src="CarImagesServlet?file=<%= car.getCarImage() %>" 
                     alt="<%= car.getCarModel() %>" 
                     class="car-image" />
                <div class="car-card-body">
                    <div class="car-model"><%= car.getCarModel() %></div>
                    <div class="car-plate"><%= car.getPlateNumber() %></div>
                    <div class="car-details">
                        <span>🎨 <%= car.getCarColour() %></span>
                        <span>👤 <%= car.getOwnerName() %></span>
                    </div>
                    <div class="car-rate">RM <%= String.format("%.2f", car.getRentalRate()) %> <small>/day</small></div>
                </div>
                <div class="car-card-footer">
                    <a href="TenantConfirmBooking.jsp?carId=<%= car.getCarId() %>" class="btn" style="width:100%; text-align:center;">
                        Book Now
                    </a>
                </div>
            </div>
            <% } %>
        </div>
    <% } %>
</div>
</body>
</html>