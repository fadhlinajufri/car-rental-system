<%-- 
    Document   : ManageOwner
    Created on : Jun 30, 2026, 10:09:11 AM
    Author     : USER
--%>

<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="java.util.*, rent.bean.*" %>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Owners - VroomGo</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<%
    HttpSession adminSession = request.getSession(false);
    AdminBean admin = null;
    if (adminSession != null) {
        admin = (AdminBean) adminSession.getAttribute("loggedAdmin");
    }
    if (admin == null) {
        response.sendRedirect("AdminLogin.jsp");
        return;
    }
%>

<div class="navbar">
    <a href="AdminDashboardServlet" class="navbar-logo">
        <img src="images/logovroomgo_2.png" alt="VroomGo Logo" />
    </a>
    <div class="navbar-right">
        <span>Hello, <%= admin.getAdminName() %></span>
        <a href="AdminLogoutServlet" class="logout">Logout</a>
    </div>
</div>

<div class="admin-layout">
    <div class="sidebar">
        <a href="AdminDashboardServlet" class="sidebar-link">Dashboard</a>
        <a href="ManageOwnerServlet" class="sidebar-link active">Manage Owners</a>
        <a href="ManageTenantServlet" class="sidebar-link">Manage Tenants</a>
        <a href="ManageCarsServlet" class="sidebar-link">Manage Cars</a>
        <a href="ManageRentDetailsServlet" class="sidebar-link">Rent Details</a>
        <a href="ManageTransactionServlet" class="sidebar-link">Transactions</a>
        <a href="ManageReportsServlet" class="sidebar-link">Reports</a>
        <a href="ManageWithdrawServlet" class="sidebar-link">Owner Withdrawal</a>
        <a href="AdminAddAdminServlet" class="sidebar-link">Add Admin</a>
    </div>
    <div class="admin-content">
        <div class="page-title">Manage Owners</div>
        
        <% String updated     = request.getParameter("updated");
           String deleted     = request.getParameter("deleted");
           String deleteError = request.getParameter("deleteError");
           String error2      = request.getParameter("error");
        %>
        <% if ("true".equals(updated))     { %><div class="alert alert-success">Owner updated successfully!</div><% } %>
        <% if ("true".equals(deleted))     { %><div class="alert alert-success">Owner deleted successfully!</div><% } %>
        <% if ("true".equals(deleteError)) { %><div class="alert alert-error">Cannot delete — owner still has cars listed.</div><% } %>
        <% if ("true".equals(error2))      { %><div class="alert alert-error">An error occurred. Email may already be in use.</div><% } %>
        
        <%
            List<OwnerBean> ownerList = (List<OwnerBean>) request.getAttribute("ownerList");
            if (ownerList == null || ownerList.isEmpty()) {
        %>
            <div class="no-data"><p>No owners registered yet.</p></div>
        <% } else { %>
        <table>
            <tr>
                <th>Owner ID</th>
                <th>Name</th>
                <th>Phone</th>
                <th>Email</th>
                <th>Actions</th>
            </tr>
            <% for (OwnerBean owner : ownerList) { %>
            <tr>
                <td><%= owner.getOwnerId() %></td>
                <td><%= owner.getOwnerName() %></td>
                <td><%= owner.getPhoneNumber() %></td>
                <td><%= owner.getOwnerEmail() %></td>
                <td>
                    <a href="#" onclick="openEditModal('<%= owner.getOwnerId() %>','<%= owner.getOwnerName() %>','<%= owner.getPhoneNumber() %>','<%= owner.getOwnerEmail() %>'); return false;" class="btn-edit">Edit</a>
                    &nbsp;
                    <a href="ManageOwnerServlet?action=delete&ownerId=<%= owner.getOwnerId() %>"
                       class="btn-delete"
                       onclick="return confirm('Delete this owner?')">Delete</a>
                </td>
            </tr>
            <% } %>
        </table>
        <% } %>
    </div>
</div>

<div id="editModal" class="modal-overlay" style="display:none;">
    <div class="modal-box">
        <h3>Edit Owner</h3>
        <form action="ManageOwnerServlet" method="post">
            <input type="hidden" name="ownerId" id="modalOwnerId"/>
            <div class="form-group">
                Full Name
                <input type="text" name="ownerName" id="modalOwnerName" required/>
            </div>
            <div class="form-group">
                Phone Number
                <input type="text" name="phoneNumber" id="modalPhoneNumber" required/>
            </div>
            <div class="form-group">
                Email
                <input type="email" name="ownerEmail" id="modalOwnerEmail" required/>
            </div>

            <div class="form-actions">
                <button type="button" class="btn-secondary" onclick="closeEditModal()">Cancel</button>
                <button type="submit" class="btn">Save Changes</button>
            </div>
        </form>
    </div>
</div>

<script>
function openEditModal(ownerId, ownerName, phoneNumber, ownerEmail) {
    document.getElementById('modalOwnerId').value = ownerId;
    document.getElementById('modalOwnerName').value = ownerName;
    document.getElementById('modalPhoneNumber').value = phoneNumber;
    document.getElementById('modalOwnerEmail').value = ownerEmail;
    document.getElementById('editModal').style.display = 'flex';
}
function closeEditModal() {
    document.getElementById('editModal').style.display = 'none';
}
</script>
</body>
</html>
