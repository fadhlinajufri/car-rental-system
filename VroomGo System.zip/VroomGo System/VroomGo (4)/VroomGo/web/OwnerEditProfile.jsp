<%-- 
    Document   : OwnerEditProfile
    Created on : Jun 30, 2026, 2:43:57 PM
    Author     : USER
--%>

<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="rent.bean.OwnerBean" %>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Profile - VroomGo</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<%
    HttpSession ownerSession = request.getSession(false);
    OwnerBean owner = null;
    if (ownerSession != null) {
        owner = (OwnerBean) ownerSession.getAttribute("loggedOwner");
    }
    if (owner == null) {
        response.sendRedirect("OwnerLogin.jsp");
        return;
    }
%>

<div class="navbar">
    <a href="OwnerDashboardServlet" class="navbar-logo">
        <img src="images/logovroomgo_2.png" alt="VroomGo Logo" />
    </a>
    <div class="navbar-right">
        <span>Hello, <%= owner.getOwnerName() %></span>
        <a href="OwnerEditProfileServlet">Edit Profile</a>
        <a href="OwnerLogoutServlet" class="logout">Logout</a>
    </div>
</div>

<div class="container">
    <div class="page-title">Edit Profile</div>
    <% String error = (String) request.getAttribute("error");
       if (error != null) { %>
        <div class="alert alert-error"><%= error %></div>
    <% } %>
    
    <div class="form-card">
        <form action="OwnerEditProfileServlet" method="post">
            <div class="form-row">
                <div class="form-group">
                    Full Name
                    <input type="text" name="ownerName" required value="<%= owner.getOwnerName() %>"/>
                </div>
                <div class="form-group">
                    Phone Number
                    <input type="text" name="phoneNumber" required value="<%= owner.getPhoneNumber() %>"/>
                </div>
            </div>
            <div class="form-group">
                Email
                <input type="email" name="ownerEmail" required value="<%= owner.getOwnerEmail() %>"/>
            </div>
            <div class="form-group">
                <label>Bank Account Number</label>
                <input type="text" name="bankAccNumber" value="${loggedOwner.bankAccNumber}" />
            </div>
            <div class="form-group">
                <label>Bank Name</label>
                <input type="text" name="bankName" value="${loggedOwner.bankName}" />
            </div>
            <hr class="form-divider"/>
            
            <div class="form-group">
                <label>New Password <small style="font-weight:400; text-transform:none; color:#aaa;">(leave empty to keep current)</small></label>
                <input type="password" name="newPassword" placeholder="••••••••"/>
            </div>
            
            <div class="form-group">
                <label>Current Password <small style="font-weight:400; text-transform:none; color:#aaa;">(required to save changes)</small></label>
                <input type="password" name="currentPassword" required placeholder="••••••••"/>
            </div>
            
            <div class="form-actions">
                <a href="OwnerDashboardServlet" class="btn-secondary">Cancel</a>
                <button type="submit" class="btn">Save Changes</button>
            </div>

        </form>
    </div>
</div>
</body>
</html>
