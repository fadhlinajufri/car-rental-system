<%-- 
    Document   : TenantRegister
    Created on : Jun 29, 2026, 5:25:53 PM
    Author     : USER
--%>

<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>Tenant Register - VroomGo</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="form-page">
    <div class="form-wrapper">

        <img src="images/logovroomgo_2.png" alt="VroomGo Logo" class="form-logo" />
        <h2>Tenant <span>Registration</span></h2>

        <% String error = (String) request.getAttribute("error");
           if (error != null) { %>
            <div class="alert alert-error"><%= error %></div>
        <% } %>

        <form action="TenantRegisterServlet" method="post">
            <div class="form-group">
                <label>Full Name</label>
                <input type="text" name="tenantName" required placeholder="Ahmad bin Ali"/>
            </div>
            <div class="form-group">
                <label>Phone Number</label>
                <input type="text" name="phoneNumber" required placeholder="01X-XXXXXXX"/>
            </div>
            <div class="form-group">
                <label>License Number</label>
                <input type="text" name="licenseNum" required placeholder="e.g. D12345678901"/>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="tenantEmail" required placeholder="you@email.com"/>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="tenantPassword" required placeholder="••••••••"/>
            </div>
            <div class="form-group">
                <label>Confirm Password</label>
                <input type="password" name="confirmPassword" required placeholder="••••••••"/>
            </div>
            <input type="submit" value="Create Account" class="form-submit"/>
        </form>

        <hr class="form-divider"/>
        <div class="form-link">
            Already have an account? <a href="TenantLogin.jsp">Login here</a>
        </div>
    </div>
</div>
</body>
</html>
