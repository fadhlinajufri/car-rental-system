<%-- 
    Document   : TenantLogin
    Created on : Jun 29, 2026, 5:29:14 PM
    Author     : USER
--%>

<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>Tenant Login - VroomGo</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="form-page">
    <div class="form-wrapper">
        
        <img src="images/logovroomgo_2.png" alt="VroomGo Logo" class="form-logo" />
        <h2>Tenant <span>Login</span></h2>
        
        <% String registered = request.getParameter("registered");
           if ("true".equals(registered)) { %>
            <div class="alert alert-success">Registration successful! Please login.</div>
        <% } %>
        
        <% String error = (String) request.getAttribute("error");
           if (error != null) { %>
            <div class="alert alert-error"><%= error %></div>
        <% } %>
        
        <form action="TenantLoginServlet" method="post">
            <div class="form-group">
                Email
                <input type="email" name="tenantEmail" required placeholder="you@email.com"/>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="tenantPassword" required placeholder="••••••••"/>
            </div>
            <input type="submit" value="Login" class="form-submit"/>
        </form>

        <hr class="form-divider"/>
        <div class="form-link">
            Don't have an account? <a href="TenantRegister.jsp">Register here</a>
        </div>
    </div>
</div>
</body>
</html>
