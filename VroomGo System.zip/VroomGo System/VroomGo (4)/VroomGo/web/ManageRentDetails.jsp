<%-- 
    Document   : ManageRentDetails
    Created on : Jun 30, 2026, 2:12:58 PM
    Author     : USER
--%>

<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="java.util.*, rent.bean.*" %>
<!DOCTYPE html>
<html>
<head>
    <title>Rent Details - VroomGo</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<%
    HttpSession adminSession = request.getSession(false);
    AdminBean admin = null;
    if (adminSession != null) {
        admin = (AdminBean) adminSession.getAttribute("loggedAdmin");
    }
    if (admin == null) {
        response.sendRedirect("AdminLogin.jsp");
        return;
    }
%>

<div class="navbar">
    <a href="AdminDashboardServlet" class="navbar-logo">
        <img src="images/logovroomgo_2.png" alt="VroomGo Logo" />
    </a>
    <div class="navbar-right">
        <span>Hello, <%= admin.getAdminName() %></span>
        <a href="AdminLogoutServlet" class="logout">Logout</a>
    </div>
</div>

<div class="admin-layout">
    <div class="sidebar">
        <a href="AdminDashboardServlet" class="sidebar-link">Dashboard</a>
        <a href="ManageOwnerServlet" class="sidebar-link">Manage Owners</a>
        <a href="ManageTenantServlet" class="sidebar-link">Manage Tenants</a>
        <a href="ManageCarsServlet" class="sidebar-link">Manage Cars</a>
        <a href="ManageRentDetailsServlet" class="sidebar-link active">Rent Details</a>
        <a href="ManageTransactionServlet" class="sidebar-link">Transactions</a>
        <a href="ManageReportsServlet" class="sidebar-link">Reports</a>
        <a href="ManageWithdrawServlet" class="sidebar-link">Owner Withdrawal</a>
        <a href="AdminAddAdminServlet" class="sidebar-link">Add Admin</a>
    </div>
    
    
    <div class="admin-content">
        <div class="page-title">Rent Details</div>
        
        <%
            List<RentDetailsBean> rentList = (List<RentDetailsBean>) request.getAttribute("rentList");
            if (rentList == null || rentList.isEmpty()) {
        %>
            <div class="no-data"><p>No rental records yet.</p></div>
        <% } else { %>
        <table>
            <tr>
                <th>Rent ID</th>
                <th>Tenant</th>
                <th>Car</th>
                <th>Owner</th>
                <th>Rent Date</th>
                <th>Return Date</th>
                <th>Payment</th>
                <th>Status</th>
            </tr>
            <%
                for (RentDetailsBean rent : rentList) {
                    String badgeClass = "badge-other";
                    if ("Confirmed".equals(rent.getStatus())) badgeClass = "badge-available";
                    else if ("Pending".equals(rent.getStatus())) badgeClass = "badge-rented";
            %>
            <tr>
                <td><%= rent.getRentId() %></td>
                <td><%= rent.getTenantName() %></td>
                <td><%= rent.getCarModel() %> (<%= rent.getPlateNum() %>)</td>
                <td><%= rent.getOwnerName() %></td>
                <td><%= rent.getRentDate() %></td>
                <td><%= rent.getReturnDate() %></td>
                <td>RM <%= String.format("%.2f", rent.getPayment()) %></td>
                <td><span class="badge <%= badgeClass %>"><%= rent.getStatus() %></span></td>
            </tr>
            <% } %>
        </table>
        <% } %>
    </div>
</div>
</body>
</html>
