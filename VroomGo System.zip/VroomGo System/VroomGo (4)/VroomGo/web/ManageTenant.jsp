<%-- 
    Document   : ManageTenant
    Created on : Jun 30, 2026, 2:11:13 PM
    Author     : USER
--%>

<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="java.util.*, rent.bean.*" %>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Tenants - VroomGo</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<%
    HttpSession adminSession = request.getSession(false);
    AdminBean admin = null;
    if (adminSession != null) {
        admin = (AdminBean) adminSession.getAttribute("loggedAdmin");
    }
    if (admin == null) {
        response.sendRedirect("AdminLogin.jsp");
        return;
    }
%>

<div class="navbar">
    <a href="AdminDashboardServlet" class="navbar-logo">
        <img src="images/logovroomgo_2.png" alt="VroomGo Logo" />
    </a>
    <div class="navbar-right">
        <span>Hello, <%= admin.getAdminName() %></span>
        <a href="AdminLogoutServlet" class="logout">Logout</a>
    </div>
</div>

<div class="admin-layout">
    <div class="sidebar">
        <a href="AdminDashboardServlet" class="sidebar-link">Dashboard</a>
        <a href="ManageOwnerServlet" class="sidebar-link">Manage Owners</a>
        <a href="ManageTenantServlet" class="sidebar-link active">Manage Tenants</a>
        <a href="ManageCarsServlet" class="sidebar-link">Manage Cars</a>
        <a href="ManageRentDetailsServlet" class="sidebar-link">Rent Details</a>
        <a href="ManageTransactionServlet" class="sidebar-link">Transactions</a>
        <a href="ManageReportsServlet" class="sidebar-link">Reports</a>
        <a href="ManageWithdrawServlet" class="sidebar-link">Owner Withdrawal</a>
        <a href="AdminAddAdminServlet" class="sidebar-link">Add Admin</a>
    </div>

    <div class="admin-content">
        <div class="page-title">Manage Tenants</div>
        <% String updated     = request.getParameter("updated");
           String deleted     = request.getParameter("deleted");
           String deleteError = request.getParameter("deleteError");
           String error2      = request.getParameter("error");
        %>
        <% if ("true".equals(updated))     { %><div class="alert alert-success">Tenant updated successfully!</div><% } %>
        <% if ("true".equals(deleted))     { %><div class="alert alert-success">Tenant deleted successfully!</div><% } %>
        <% if ("true".equals(deleteError)) { %><div class="alert alert-error">Cannot delete — tenant has booking history.</div><% } %>
        <% if ("true".equals(error2))      { %><div class="alert alert-error">An error occurred. Email may already be in use.</div><% } %>
        
        <%
            List<TenantBean> tenantList = (List<TenantBean>) request.getAttribute("tenantList");
            if (tenantList == null || tenantList.isEmpty()) {
        %>
            <div class="no-data"><p>No tenants registered yet.</p></div>
        <% } else { %>
        <table>
            <tr>
                <th>Tenant ID</th>
                <th>Name</th>
                <th>Phone</th>
                <th>License No.</th>
                <th>Email</th>
                <th>Actions</th>
            </tr>
            <% for (TenantBean tenant : tenantList) { %>
            <tr>
                <td><%= tenant.getTenantId() %></td>
                <td><%= tenant.getTenantName() %></td>
                <td><%= tenant.getPhoneNumber() %></td>
                <td><%= tenant.getLicenseNum() %></td>
                <td><%= tenant.getTenantEmail() %></td>
                <td>
                    <a href="#" onclick="openEditModal('<%= tenant.getTenantId() %>','<%= tenant.getTenantName() %>','<%= tenant.getPhoneNumber() %>','<%= tenant.getLicenseNum() %>','<%= tenant.getTenantEmail() %>'); return false;" class="btn-edit">Edit</a>
                    &nbsp;
                    <a href="ManageTenantServlet?action=delete&tenantId=<%= tenant.getTenantId() %>"
                       class="btn-delete"
                       onclick="return confirm('Delete this tenant?')">Delete</a>
                </td>
            </tr>
            <% } %>
        </table>
        <% } %>
    </div>
</div>

<div id="editModal" class="modal-overlay" style="display:none;">
    <div class="modal-box">
        <h3>Edit Tenant</h3>
        <form action="ManageTenantServlet" method="post">
            <input type="hidden" name="tenantId" id="modalTenantId"/>
            <div class="form-group">
                Full Name
                <input type="text" name="tenantName" id="modalTenantName" required/>
            </div>
            <div class="form-group">
                Phone Number
                <input type="text" name="phoneNumber" id="modalPhoneNumber" required/>
            </div>
            <div class="form-group">
                License Number
                <input type="text" name="licenseNum" id="modalLicenseNum" required/>
            </div>
            <div class="form-group">
                Email
                <input type="email" name="tenantEmail" id="modalTenantEmail" required/>
            </div>
            <div class="form-actions">
                <button type="button" class="btn-secondary" onclick="closeEditModal()">Cancel</button>
                <button type="submit" class="btn">Save Changes</button>
            </div>
        </form>
    </div>
</div>

<script>
function openEditModal(tenantId, tenantName, phoneNumber, licenseNum, tenantEmail) {
    document.getElementById('modalTenantId').value = tenantId;
    document.getElementById('modalTenantName').value = tenantName;
    document.getElementById('modalPhoneNumber').value = phoneNumber;
    document.getElementById('modalLicenseNum').value = licenseNum;
    document.getElementById('modalTenantEmail').value = tenantEmail;
    document.getElementById('editModal').style.display = 'flex';
}
function closeEditModal() {
    document.getElementById('editModal').style.display = 'none';
}
</script>
</body>
</html>
