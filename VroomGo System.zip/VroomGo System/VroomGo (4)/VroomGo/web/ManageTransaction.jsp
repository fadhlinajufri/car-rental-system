<%-- 
    Document   : ManageTransaction
    Created on : Jun 30, 2026, 2:14:08 PM
    Author     : USER
--%>

<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="java.util.*, rent.bean.*" %>
<!DOCTYPE html>
<html>
<head>
    <title>Transactions - VroomGo</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<%
    HttpSession adminSession = request.getSession(false);
    AdminBean admin = null;
    if (adminSession != null) {
        admin = (AdminBean) adminSession.getAttribute("loggedAdmin");
    }
    if (admin == null) {
        response.sendRedirect("AdminLogin.jsp");
        return;
    }
%>

<div class="navbar">
    <a href="AdminDashboardServlet" class="navbar-logo">
        <img src="images/logovroomgo_2.png" alt="VroomGo Logo" />
    </a>
    <div class="navbar-right">
        <span>Hello, <%= admin.getAdminName() %></span>
        <a href="AdminLogoutServlet" class="logout">Logout</a>
    </div>
</div>

<div class="admin-layout">
    <div class="sidebar">
        <a href="AdminDashboardServlet" class="sidebar-link">Dashboard</a>
        <a href="ManageOwnerServlet" class="sidebar-link">Manage Owners</a>
        <a href="ManageTenantServlet" class="sidebar-link">Manage Tenants</a>
        <a href="ManageCarsServlet" class="sidebar-link">Manage Cars</a>
        <a href="ManageRentDetailsServlet" class="sidebar-link">Rent Details</a>
        <a href="ManageTransactionServlet" class="sidebar-link active">Transactions</a>
        <a href="ManageReportsServlet" class="sidebar-link">Reports</a>
        <a href="ManageWithdrawServlet" class="sidebar-link">Owner Withdrawal</a>
        <a href="AdminAddAdminServlet" class="sidebar-link">Add Admin</a>
    </div>

    <div class="admin-content">
        <div class="page-title">Transactions</div>
        <%
            List<TransactionBean> txnList = (List<TransactionBean>) request.getAttribute("txnList");
            if (txnList == null || txnList.isEmpty()) {
        %>
            <div class="no-data"><p>No transactions yet.</p></div>
        <% } else { %>
        <table>
            <tr>
                <th>Transaction ID</th>
                <th>Rent ID</th>
                <th>Date</th>
                <th>Amount</th>
                <th>Payment Method</th>
                <th>Status</th>
            </tr>
            <% for (TransactionBean txn : txnList) { %>
            <tr>
                <td><%= txn.getTransactionId() %></td>
                <td><%= txn.getRentId() %></td>
                <td><%= txn.getTransactionDate() %></td>
                <td>RM <%= String.format("%.2f", txn.getAmount()) %></td>
                <td><%= txn.getPaymentMethod() %></td>
                <td><span class="badge badge-available"><%= txn.getTransactionStatus() %></span></td>
            </tr>
            <% } %>
        </table>
        <% } %>
    </div>
</div>
</body>
</html>
