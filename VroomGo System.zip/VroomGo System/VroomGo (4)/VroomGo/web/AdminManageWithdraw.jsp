<%-- 
    Document   : AdminManageWithdraw
    Created on : Jul 15, 2026
    Author     : USER
--%>
<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="java.util.*, rent.bean.*" %>
<!DOCTYPE html>
<html>
<head>
    <title>Owner Withdrawal - VroomGo</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<%
    HttpSession adminSession = request.getSession(false);
    AdminBean admin = null;
    if (adminSession != null) {
        admin = (AdminBean) adminSession.getAttribute("loggedAdmin");
    }
    if (admin == null) {
        response.sendRedirect("AdminLogin.jsp");
        return;
    }
%>

<div class="navbar">
    <a href="AdminDashboardServlet" class="navbar-logo">
        <img src="images/logovroomgo_2.png" alt="VroomGo Logo" />
    </a>
    <div class="navbar-right">
        <span>Hello, <%= admin.getAdminName() %></span>
        <a href="AdminEditProfileServlet">Edit Profile</a>
        <a href="AdminLogoutServlet" class="logout">Logout</a>
    </div>
</div>

<div class="admin-layout">
    <div class="sidebar">
        <a href="AdminDashboardServlet" class="sidebar-link">Dashboard</a>
        <a href="ManageOwnerServlet" class="sidebar-link">Manage Owners</a>
        <a href="ManageTenantServlet" class="sidebar-link">Manage Tenants</a>
        <a href="ManageCarsServlet" class="sidebar-link">Manage Cars</a>
        <a href="ManageRentDetailsServlet" class="sidebar-link">Rent Details</a>
        <a href="ManageTransactionServlet" class="sidebar-link">Transactions</a>
        <a href="ManageReportsServlet" class="sidebar-link">Reports</a>
        <a href="ManageWithdrawServlet" class="sidebar-link active">Owner Withdrawal</a>
        <a href="AdminAddAdminServlet" class="sidebar-link">Add Admin</a>
    </div>

    <div class="admin-content">
        <div class="page-title">Owner Withdrawal</div>

        <% if ("true".equals(request.getParameter("withdrawProcessed"))) { %>
            <div class="alert alert-success">Withdrawal request processed successfully!</div>
        <% } %>
        <% if (request.getParameter("withdrawError") != null) { %>
            <div class="alert alert-error"><%= request.getParameter("withdrawError") %></div>
        <% } %>
        <% if (request.getAttribute("error") != null) { %>
            <div class="alert alert-error"><%= request.getAttribute("error") %></div>
        <% } %>

        <%
            List<WithdrawalBean> withdrawRequests = (List<WithdrawalBean>) request.getAttribute("withdrawRequests");
            if (withdrawRequests == null || withdrawRequests.isEmpty()) {
        %>
            <div class="no-data">
                <p>No withdrawal requests found.</p>
            </div>
        <% } else { %>
            <table>
                <tr>
                    <th>Withdraw ID</th>
                    <th>Owner</th>
                    <th>Bank</th>
                    <th>Account No.</th>
                    <th>Amount</th>
                    <th>Status</th>
                    <th>Requested</th>
                    <th>Processed</th>
                    <th>Remarks</th>
                    <th>Action</th>
                </tr>
                <%
                    for (WithdrawalBean w : withdrawRequests) {
                        String badgeClass;
                        String wStatus = w.getStatus();
                        if ("Paid".equals(wStatus)) {
                            badgeClass = "badge-available";
                        } else if ("Approved".equals(wStatus)) {
                            badgeClass = "badge-available";
                        } else if ("Pending".equals(wStatus)) {
                            badgeClass = "badge-rented";
                        } else if ("Declined".equals(wStatus)) {
                            badgeClass = "badge-other";
                        } else {
                            badgeClass = "badge-other";
                        }
                %>
                <tr>
                    <td><%= w.getWithdrawId() %></td>
                    <td><%= w.getOwnerName() %></td>
                    <td><%= w.getBankName() %></td>
                    <td><%= w.getBankAccNumber() %></td>
                    <td>RM <%= String.format("%.2f", w.getAmount()) %></td>
                    <td><span class="badge <%= badgeClass %>"><%= w.getStatus().toUpperCase() %></span></td>
                    <td><%= w.getRequestDate() %></td>
                    <td><%= w.getProcessedDate() != null ? w.getProcessedDate() : "-" %></td>
                    <td><%= w.getRemarks() != null ? w.getRemarks() : "-" %></td>
                    <td>
                        <% if ("Pending".equals(wStatus)) { %>
                            <form action="AdminProcessWithdrawServlet" method="post" style="display:inline;">
                                <input type="hidden" name="withdrawId" value="<%= w.getWithdrawId() %>">
                                <input type="hidden" name="action" value="approve">
                                <button type="submit" class="btn-edit"
                                        onclick="return confirm('Approve this withdrawal?')">Approve</button>
                            </form>
                            &nbsp;
                            <a href="#" class="btn-delete"
                               onclick="document.getElementById('declineModal-<%= w.getWithdrawId() %>').style.display='flex'; return false;">Decline</a>

                            <div class="modal-overlay" id="declineModal-<%= w.getWithdrawId() %>" style="display:none;">
                                <div class="modal-box">
                                    <h3>Decline Withdrawal <%= w.getWithdrawId() %></h3>
                                    <form action="AdminProcessWithdrawServlet" method="post">
                                        <input type="hidden" name="withdrawId" value="<%= w.getWithdrawId() %>">
                                        <input type="hidden" name="action" value="decline">
                                        <div class="form-group">
                                            <label>Reason</label>
                                            <textarea name="remarks" rows="3" required></textarea>
                                        </div>
                                        <div class="form-actions">
                                            <a href="#" class="btn-secondary"
                                               onclick="document.getElementById('declineModal-<%= w.getWithdrawId() %>').style.display='none'; return false;">Cancel</a>
                                            <button type="submit" class="btn">Confirm Decline</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        <% } else if ("Approved".equals(wStatus)) { %>
                            <form action="AdminProcessWithdrawServlet" method="post" style="display:inline;">
                                <input type="hidden" name="withdrawId" value="<%= w.getWithdrawId() %>">
                                <input type="hidden" name="action" value="pay">
                                <button type="submit" class="btn-edit"
                                        onclick="return confirm('Mark this withdrawal as paid?')">Mark as Paid</button>
                            </form>
                        <% } else { %>
                            -
                        <% } %>
                    </td>
                </tr>
                <% } %>
            </table>
        <% } %>
    </div>
</div>
</body>
</html>