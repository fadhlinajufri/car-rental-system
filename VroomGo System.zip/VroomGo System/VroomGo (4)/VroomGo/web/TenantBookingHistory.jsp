<%-- 
    Document   : TenantBookingHistory
    Created on : Jul 14, 2026, 12:19:16 PM
    Author     : user
--%>

<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="java.util.*, rent.bean.*" %>
<!DOCTYPE html>
<html>
<head>
    <title>Booking History - VroomGo</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<%
    HttpSession tenantSession = request.getSession(false);
    TenantBean tenant = null;
    if (tenantSession != null) {
        tenant = (TenantBean) tenantSession.getAttribute("loggedTenant");
    }
    if (tenant == null) {
        response.sendRedirect("TenantLogin.jsp");
        return;
    }
%>

<div class="navbar">
    <a href="TenantDashboardServlet" class="navbar-logo">
        <img src="images/logovroomgo_2.png" alt="VroomGo Logo" />
    </a>
    <div class="navbar-right">
        <span>Hello, <%= tenant.getTenantName() %></span>
        <a href="TenantDashboardServlet">Dashboard</a>
        <a href="TenantEditProfileServlet">Edit Profile</a>
        <a href="TenantLogoutServlet" class="logout">Logout</a>
    </div>
</div>

<div class="container">
    <div class="page-title">Booking History</div>

    <% String error = (String) request.getAttribute("error");
       if (error != null) { %>
        <div class="alert alert-error"><%= error %></div>
    <% } %>

    <div class="section-header">
        <h2>All Bookings</h2>
        <a href="TenantDashboardServlet" class="btn-secondary">Back to Dashboard</a>
    </div>

    <%
        List<RentDetailsBean> historyList = (List<RentDetailsBean>) request.getAttribute("historyList");
        if (historyList == null || historyList.isEmpty()) {
    %>
        <div class="no-data">
            <p>You have no booking history yet.</p>
        </div>
    <% } else { %>
        <table>
            <tr>
                <th>Rent ID</th>
                <th>Car</th>
                <th>Rent Date</th>
                <th>Return Date</th>
                <th>Payment</th>
                <th>Status</th>
            </tr>
            <% for (RentDetailsBean rent : historyList) {
                String status = rent.getStatus() == null ? "" : rent.getStatus();
                String badgeClass;
                if (status.equalsIgnoreCase("Returned") || status.equalsIgnoreCase("Completed")) {
                    badgeClass = "badge-available";
                } else if (status.equalsIgnoreCase("Pending") || status.equalsIgnoreCase("Rented")
                        || status.equalsIgnoreCase("Active") || status.equalsIgnoreCase("Confirmed")) {
                    badgeClass = "badge-rented";
                } else {
                    badgeClass = "badge-other";
                }
            %>
            <tr>
                <td><%= rent.getRentId() %></td>
                <td><%= rent.getCarModel() %> (<%= rent.getPlateNum() %>)</td>
                <td><%= rent.getRentDate() %></td>
                <td><%= rent.getReturnDate() %></td>
                <td>RM <%= String.format("%.2f", rent.getPayment()) %></td>
                <td><span class="badge <%= badgeClass %>"><%= status %></span></td>
            </tr>
            <% } %>
        </table>
    <% } %>
</div>
</body>
</html>
