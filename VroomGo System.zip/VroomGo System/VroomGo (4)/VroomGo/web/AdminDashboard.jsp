<%-- 
    Document   : AdminDashboard
    Created on : Jun 30, 2026, 9:54:02 AM
    Author     : USER
--%>

<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="rent.bean.AdminBean" %>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard - VroomGo</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<%
    HttpSession adminSession = request.getSession(false);
    AdminBean admin = null;
    if (adminSession != null) {
        admin = (AdminBean) adminSession.getAttribute("loggedAdmin");
    }
    if (admin == null) {
        response.sendRedirect("AdminLogin.jsp");
        return;
    }
%>

<div class="navbar">
    <a href="AdminDashboardServlet" class="navbar-logo">
        <img src="images/logovroomgo_2.png" alt="VroomGo Logo" />
    </a>
    <div class="navbar-right">
        <span>Hello, <%= admin.getAdminName() %></span>
        <a href="AdminEditProfileServlet">Edit Profile</a>
        <a href="AdminLogoutServlet" class="logout">Logout</a>
    </div>
</div>

<div class="admin-layout">
    
    <div class="sidebar">
        <a href="AdminDashboardServlet" class="sidebar-link active">Dashboard</a>
        <a href="ManageOwnerServlet" class="sidebar-link">Manage Owners</a>
        <a href="ManageTenantServlet" class="sidebar-link">Manage Tenants</a>
        <a href="ManageCarsServlet" class="sidebar-link">Manage Cars</a>
        <a href="ManageRentDetailsServlet" class="sidebar-link">Rent Details</a>
        <a href="ManageTransactionServlet" class="sidebar-link">Transactions</a>
        <a href="ManageReportsServlet" class="sidebar-link">Reports</a>
        <a href="ManageWithdrawServlet" class="sidebar-link">Owner Withdrawal</a>
        <a href="AdminAddAdminServlet" class="sidebar-link">Add Admin</a>
    </div>
    <div class="admin-content">
        <div class="page-title">Dashboard Overview</div>
        <% String error = (String) request.getAttribute("error");
           if (error != null) { %>
            <div class="alert alert-error"><%= error %></div>
        <% } %>
        
        
        <div class="stats">
            <div class="stat-card">
                <div class="number"><%= request.getAttribute("totalOwners") %></div>
                <div class="label">Total Owners</div>
            </div>
            <div class="stat-card">
                <div class="number"><%= request.getAttribute("totalTenants") %></div>
                <div class="label">Total Tenants</div>
            </div>
            <div class="stat-card">
                <div class="number"><%= request.getAttribute("totalCars") %></div>
                <div class="label">Total Cars</div>
            </div>
            <div class="stat-card">
                <div class="number"><%= request.getAttribute("totalBookings") %></div>
                <div class="label">Total Bookings</div>
            </div>
        </div>
                
        <div class="revenue-card">
            <div class="revenue-label">Total Revenue</div>
            <div class="revenue-amount">RM <%= String.format("%.2f", (Double) request.getAttribute("totalRevenue")) %></div>
        </div>
    </div>
</div>
</body>
</html>