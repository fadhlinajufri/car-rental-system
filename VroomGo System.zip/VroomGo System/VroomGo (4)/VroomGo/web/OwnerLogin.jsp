<%-- 
    Document   : owner_login
    Created on : Jun 26, 2026, 2:46:06 PM
    Author     : USER
--%>

<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>Owner Login - VroomGo</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="form-page">
    <div class="form-wrapper">

        <!-- YOUR LOGO HERE — place logo.png inside web/images/ -->
        <img src="images/logovroomgo_2.png" alt="VroomGo Logo" class="form-logo" />

        <h2>Owner <span>Login</span></h2>

        <% String registered = request.getParameter("registered");
           if ("true".equals(registered)) { %>
            <div class="alert alert-success">Registration successful! Please login.</div>
        <% } %>

        <% String error = (String) request.getAttribute("error");
           if (error != null) { %>
            <div class="alert alert-error"><%= error %></div>
        <% } %>

        <form action="OwnerLoginServlet" method="post">
            <div class="form-group">
                Email
                <input type="email" name="ownerEmail" required placeholder="you@email.com"/>
            </div>
            <div class="form-group">
                Password
                <input type="password" name="ownerPassword" required placeholder="••••••••"/>
            </div>
            <input type="submit" value="Login" class="form-submit"/>
        </form>

        <hr class="form-divider"/>
        <div class="form-link">
            Don't have an account? <a href="OwnerRegister.jsp">Register here</a>
        </div>
    </div>
</div>
</body>
</html>