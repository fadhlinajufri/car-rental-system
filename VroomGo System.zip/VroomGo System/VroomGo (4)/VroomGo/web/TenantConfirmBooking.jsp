<%-- 
    Document   : TenantConfirmBooking
    Created on : Jun 29, 2026, 5:32:57 PM
    Author     : USER
--%>

<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="rent.bean.*" %>
<%@ page import="java.sql.*" %>
<%@ page import="util.DBConnection" %>
<!DOCTYPE html>
<html>
<head>
    <title>Confirm Booking - VroomGo</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<%
    HttpSession tenantSession = request.getSession(false);
    TenantBean tenant = null;
    if (tenantSession != null) {
        tenant = (TenantBean) tenantSession.getAttribute("loggedTenant");
    }
    if (tenant == null) {
        response.sendRedirect("TenantLogin.jsp");
        return;
    }
    
    String carId = request.getParameter("carId");
    if (carId == null || carId.isEmpty()) {
        response.sendRedirect("TenantDashboardServlet");
        return;
    }

    // Fetch the car's rental rate
    double rentalRate = 0;
    Connection conn = null;
    try {
        conn = DBConnection.getConnection();
        String carSql = "SELECT rentalRate FROM Car WHERE carId = ?";
        PreparedStatement carPs = conn.prepareStatement(carSql);
        carPs.setString(1, carId);
        ResultSet carRs = carPs.executeQuery();
        if (carRs.next()) {
            rentalRate = carRs.getDouble("rentalRate");
        } else {
            response.sendRedirect("TenantDashboardServlet");
            return;
        }
    } catch (SQLException e) {
        e.printStackTrace();
        response.sendRedirect("TenantDashboardServlet");
        return;
    } finally {
        DBConnection.closeConnection(conn);
    }
%>

<div class="navbar">
    <a href="TenantDashboardServlet" class="navbar-logo">
        <img src="images/logovroomgo_2.png" alt="VroomGo Logo" />
    </a>
    <div class="navbar-right">
        <span>Hello, <%= tenant.getTenantName() %></span>
        <a href="TenantLogoutServlet" class="logout">Logout</a>
    </div>
</div>

<div class="container">
    <div class="page-title">Confirm Booking</div>
    
    <% String error = (String) request.getAttribute("error");
       if (error != null) { %>
        <div class="alert alert-error"><%= error %></div>
    <% } %>
    
    <div class="form-card">
        <form action="TenantConfirmBookingServlet" method="post">
            <input type="hidden" name="carId" value="<%= carId %>"/>
            <div class="form-row">
                <div class="form-group">
                    Rent Date
                    <input type="date" name="rentDate" required/>
                </div>
                <div class="form-group">
                    Return Date
                    <input type="date" name="returnDate" required/>
                </div>
            </div>
            <div class="booking-summary" id="summary" style="display:none;">
                <div class="summary-row">
                    <span>Number of Days</span>
                    <span id="numDays">-</span>
                </div>
                <div class="summary-row">
                    <span>Estimated Total</span>
                    <span id="totalPrice">-</span>
                </div>
            </div>
            
            <div class="form-actions">
                <a href="TenantDashboardServlet" class="btn-secondary">Cancel</a>
                <button type="submit" class="btn">Confirm Booking</button>
            </div>
        </form>
    </div>
</div>
<script>
    const rentalRate = <%= rentalRate %>;

    const rentDate   = document.querySelector('[name="rentDate"]');
    const returnDate = document.querySelector('[name="returnDate"]');

    function calculateDays() {
        if (rentDate.value && returnDate.value) {
            const d1 = new Date(rentDate.value);
            const d2 = new Date(returnDate.value);
            const days = Math.ceil((d2 - d1) / (1000 * 60 * 60 * 24));
            if (days > 0) {
                const total = days * rentalRate;
                document.getElementById('numDays').textContent = days + ' day(s)';
                document.getElementById('totalPrice').textContent =
                    'RM ' + total.toFixed(2);
                document.getElementById('summary').style.display = 'block';
            } else {
                document.getElementById('summary').style.display = 'none';
            }
        }
    }

    rentDate.addEventListener('change', calculateDays);
    returnDate.addEventListener('change', calculateDays);

    const today = new Date().toISOString().split('T')[0];
    rentDate.min   = today;
    returnDate.min = today;
</script>
</body>
</html>