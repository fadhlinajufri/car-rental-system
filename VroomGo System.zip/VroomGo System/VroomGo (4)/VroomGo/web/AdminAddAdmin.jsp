<%-- 
    Document   : AdminAddAdmin
    Created on : Jun 30, 2026, 2:17:11 PM
    Author     : USER
--%>

<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="rent.bean.AdminBean" %>
<!DOCTYPE html>
<html>
<head>
    <title>Add Admin - VroomGo</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<%
    HttpSession adminSession = request.getSession(false);
    AdminBean admin = null;
    if (adminSession != null) {
        admin = (AdminBean) adminSession.getAttribute("loggedAdmin");
    }
    if (admin == null) {
        response.sendRedirect("AdminLogin.jsp");
        return;
    }
%>

<div class="navbar">
    <a href="AdminDashboardServlet" class="navbar-logo">
        <img src="images/logovroomgo_2.png" alt="VroomGo Logo" />
    </a>
    <div class="navbar-right">
        <span>Hello, <%= admin.getAdminName() %></span>
        <a href="AdminLogoutServlet" class="logout">Logout</a>
    </div>
</div>

<div class="admin-layout">
    <div class="sidebar">
        <a href="AdminDashboardServlet" class="sidebar-link">Dashboard</a>
        <a href="ManageOwnerServlet" class="sidebar-link">Manage Owners</a>
        <a href="ManageTenantServlet" class="sidebar-link">Manage Tenants</a>
        <a href="ManageCarsServlet" class="sidebar-link">Manage Cars</a>
        <a href="ManageRentDetailsServlet" class="sidebar-link">Rent Details</a>
        <a href="ManageTransactionServlet" class="sidebar-link">Transactions</a>
        <a href="ManageReportsServlet" class="sidebar-link">Reports</a>
        <a href="ManageWithdrawServlet" class="sidebar-link">Owner Withdrawal</a>
        <a href="AdminAddAdminServlet" class="sidebar-link active">Add Admin</a>
    </div>
    
    
    <div class="admin-content">
        <div class="page-title">Add New Admin</div>
        
        <% String added = request.getParameter("added");
           if ("true".equals(added)) { %>
            <div class="alert alert-success">New admin added successfully!</div>
        <% } %>
        <% String error = (String) request.getAttribute("error");
           if (error != null) { %>
            <div class="alert alert-error"><%= error %></div>
        <% } %>
        
        <div class="form-card">
            <form action="AdminAddAdminServlet" method="post">
                <div class="form-group">
                    Full Name
                    <input type="text" name="adminName" required/>
                </div>
                <div class="form-group">
                    Email
                    <input type="email" name="adminEmail" required/>
                </div>
                <div class="form-group">
                    Password
                    <input type="password" name="adminPassword" required/>
                </div>
                <div class="form-actions">
                    <button type="submit" class="btn">Add Admin</button>
                </div>
            </form>
        </div>
    </div>
</div>
</body>
</html>
