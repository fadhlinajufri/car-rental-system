<%-- 
    Document   : OwnerRegister
    Created on : Jun 26, 2026, 3:23:05 PM
    Author     : USER
--%>

<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>Owner Register - VroomGo</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="form-page">
    <div class="form-wrapper">

        <!-- YOUR LOGO HERE -->
        <img src="images/logovroomgo_2.png" alt="VroomGo Logo" class="form-logo" />

        <h2>Owner <span>Registration</span></h2>

        <% String error = (String) request.getAttribute("error");
           if (error != null) { %>
            <div class="alert alert-error"><%= error %></div>
        <% } %>

        <form action="OwnerRegisterServlet" method="post">
            <div class="form-group">
                Full Name
                <input type="text" name="ownerName" required placeholder="Ahmad bin Ali"/>
            </div>
            <div class="form-group">
                Phone Number
                <input type="text" name="phoneNumber" required placeholder="01X-XXXXXXX"/>
            </div>
            <div class="form-group">
                Email
                <input type="email" name="ownerEmail" required placeholder="you@email.com"/>
            </div>
            <div class="form-group">
                Password
                <input type="password" name="ownerPassword" required placeholder="••••••••"/>
            </div>
            <div class="form-group">
                Confirm Password
                <input type="password" name="confirmPassword" required placeholder="••••••••"/>
            </div>
            <input type="submit" value="Create Account" class="form-submit"/>
        </form>

        <hr class="form-divider"/>
        <div class="form-link">
            Already have an account? <a href="OwnerLogin.jsp">Login here</a>
        </div>
    </div>
</div>
</body>
</html>