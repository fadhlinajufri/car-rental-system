<%-- 
    Document   : AdminEditProfile
    Created on : Jul 14, 2026, 2:14:17 AM
    Author     : user
--%>

<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="rent.bean.AdminBean" %>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Profile - VroomGo</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<%
    HttpSession adminSession = request.getSession(false);
    AdminBean admin = null;

    if (adminSession != null) {
        admin = (AdminBean) adminSession.getAttribute("loggedAdmin");
    }

    if (admin == null) {
        response.sendRedirect("AdminLogin.jsp");
        return;
    }
%>

<div class="navbar">
    <a href="AdminDashboardServlet" class="navbar-logo">
        <img src="images/logovroomgo_2.png" alt="VroomGo Logo"/>
    </a>

    <div class="navbar-right">
        <span>Hello, <%= admin.getAdminName() %></span>
        <a href="AdminEditProfileServlet">Edit Profile</a>
        <a href="AdminLogoutServlet" class="logout">Logout</a>
    </div>
</div>

<div class="container">

    <div class="page-title">
        Edit Profile
    </div>

    <%
        String error = (String) request.getAttribute("error");
        if (error != null) {
    %>

        <div class="alert alert-error">
            <%= error %>
        </div>

    <%
        }
    %>

    <div class="form-card">

        <form action="AdminEditProfileServlet" method="post">

            <div class="form-group">
                <label>Full Name</label>
                <input type="text"
                       name="adminName"
                       required
                       value="<%= admin.getAdminName() %>">
            </div>

            <div class="form-group">
                <label>Email</label>
                <input type="email"
                       name="adminEmail"
                       required
                       value="<%= admin.getAdminEmail() %>">
            </div>

            <hr class="form-divider">

            <div class="form-group">
                <label>
                    New Password
                    <small style="font-weight:400; text-transform:none; color:#aaa;">
                        (leave empty to keep current)
                    </small>
                </label>

                <input type="password"
                       name="newPassword"
                       placeholder="••••••••">
            </div>

            <div class="form-group">
                <label>
                    Current Password
                    <small style="font-weight:400; text-transform:none; color:#aaa;">
                        (required to save changes)
                    </small>
                </label>

                <input type="password"
                       name="currentPassword"
                       required
                       placeholder="••••••••">
            </div>

            <div class="form-actions">
                <a href="AdminDashboardServlet" class="btn-secondary">Cancel</a>

                <button type="submit" class="btn">Save Changes</button>
            </div>

        </form>

    </div>

</div>

</body>
</html>
