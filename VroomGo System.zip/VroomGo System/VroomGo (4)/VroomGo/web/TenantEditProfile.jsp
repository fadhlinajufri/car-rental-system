<%-- 
    Document   : TenantEditProfile
    Created on : Jul 14, 2026, 2:04:18 AM
    Author     : user
--%>

<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="rent.bean.TenantBean" %>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Profile - VroomGo</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<%
    HttpSession tenantSession = request.getSession(false);
    TenantBean tenant = null;

    if (tenantSession != null) {
        tenant = (TenantBean) tenantSession.getAttribute("loggedTenant");
    }

    if (tenant == null) {
        response.sendRedirect("TenantLogin.jsp");
        return;
    }
%>

<div class="navbar">
    <a href="TenantDashboardServlet" class="navbar-logo">
        <img src="images/logovroomgo_2.png" alt="VroomGo Logo"/>
    </a>

    <div class="navbar-right">
        <span>Hello, <%= tenant.getTenantName() %></span>
        <a href="TenantEditProfileServlet">Edit Profile</a>
        <a href="TenantLogoutServlet" class="logout">Logout</a>
    </div>
</div>

<div class="container">

    <div class="page-title">
        Edit Profile
    </div>

    <%
        String error = (String) request.getAttribute("error");
        if (error != null) {
    %>

        <div class="alert alert-error">
            <%= error %>
        </div>

    <%
        }
    %>

    <div class="form-card">

        <form action="TenantEditProfileServlet" method="post">

            <div class="form-row">

                <div class="form-group">
                    <label>Full Name</label>
                    <input type="text"
                           name="tenantName"
                           required
                           value="<%= tenant.getTenantName() %>">
                </div>

                <div class="form-group">
                    <label>Phone Number</label>
                    <input type="text"
                           name="phoneNumber"
                           required
                           value="<%= tenant.getPhoneNumber() %>">
                </div>

            </div>

            <div class="form-group">
                <label>License Number</label>
                <input type="text"
                       name="licenseNum"
                       required
                       value="<%= tenant.getLicenseNum() %>">
            </div>

            <div class="form-group">
                <label>Email</label>
                <input type="email"
                       name="tenantEmail"
                       required
                       value="<%= tenant.getTenantEmail() %>">
            </div>

            <hr class="form-divider">

            <div class="form-group">
                <label>
                    New Password
                    <small style="font-weight:400;text-transform:none;color:#aaa;">
                        (leave empty to keep current)
                    </small>
                </label>

                <input type="password"
                       name="newPassword"
                       placeholder="••••••••">
            </div>

            <div class="form-group">
                <label>
                    Current Password
                    <small style="font-weight:400;text-transform:none;color:#aaa;">
                        (required to save changes)
                    </small>
                </label>

                <input type="password"
                       name="currentPassword"
                       required
                       placeholder="••••••••">
            </div>

            <div class="form-actions">
                <a href="TenantDashboardServlet" class="btn-secondary">Cancel</a>

                <button type="submit" class="btn">Save Changes</button>
            </div>

        </form>

    </div>

</div>

</body>
</html>
