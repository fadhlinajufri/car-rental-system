package servlets;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import dao.AdminDAO;
public class AdminDashboardServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedAdmin") == null) {
            response.sendRedirect("AdminLogin.jsp");
            return;
        }
        AdminDAO adminDAO = new AdminDAO();
        try {
            request.setAttribute("totalOwners", adminDAO.countRows("Owner"));
            request.setAttribute("totalTenants", adminDAO.countRows("Tenant"));
            request.setAttribute("totalCars", adminDAO.countRows("Car"));
            request.setAttribute("totalBookings", adminDAO.countRows("RentDetails"));
            request.setAttribute("totalRevenue", adminDAO.getTotalRevenue());
            request.getRequestDispatcher("AdminDashboard.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Database error: " + e.getMessage());
            request.getRequestDispatcher("AdminDashboard.jsp").forward(request, response);
        }
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}