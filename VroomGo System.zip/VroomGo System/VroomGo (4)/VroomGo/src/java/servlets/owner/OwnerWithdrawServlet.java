/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets.owner;

import dao.WithdrawalDAO;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import rent.bean.OwnerBean;
import rent.bean.WithdrawalBean;

public class OwnerWithdrawServlet extends HttpServlet {

    private final WithdrawalDAO withdrawalDAO = new WithdrawalDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedOwner") == null) {
            response.sendRedirect("OwnerLogin.jsp");
            return;
        }
        OwnerBean owner = (OwnerBean) session.getAttribute("loggedOwner");

        try {
            double availableBalance = withdrawalDAO.getAvailableBalance(owner.getOwnerId());
            List<WithdrawalBean> withdrawHistory = withdrawalDAO.getWithdrawalsByOwner(owner.getOwnerId());
            request.setAttribute("availableBalance", availableBalance);
            request.setAttribute("withdrawHistory", withdrawHistory);
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("withdrawError", "Could not load withdrawal information: " + e.getMessage());
        }

        request.getRequestDispatcher("OwnerWithdraw.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}