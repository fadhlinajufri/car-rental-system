package servlets.owner;

import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import rent.bean.OwnerBean;
import dao.OwnerDAO;

public class OwnerRegisterServlet extends HttpServlet {
    private final OwnerDAO ownerDAO = new OwnerDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String name     = request.getParameter("ownerName");
        String phone    = request.getParameter("phoneNumber");
        String email    = request.getParameter("ownerEmail");
        String password = request.getParameter("ownerPassword");
        String confirm  = request.getParameter("confirmPassword");
        
        if (!password.equals(confirm)) {
            request.setAttribute("error", "Passwords do not match.");
            request.getRequestDispatcher("OwnerRegister.jsp").forward(request, response);
            return;
        }
        
        if (ownerDAO.isDuplicate("ownerEmail", email)) {
            request.setAttribute("error", "Email is already registered.");
            request.getRequestDispatcher("OwnerRegister.jsp").forward(request, response);
            return;
        }
        
        if (ownerDAO.isDuplicate("phoneNumber", phone)) {
            request.setAttribute("error", "Phone number is already registered.");
            request.getRequestDispatcher("OwnerRegister.jsp").forward(request, response);
            return;
        }
        
        if (ownerDAO.isDuplicate("ownerPassword", password)) {
            request.setAttribute("error", "This password is already in use. Please choose a different one.");
            request.getRequestDispatcher("OwnerRegister.jsp").forward(request, response);
            return;
        }
        
        OwnerBean newOwner = new OwnerBean();
        newOwner.setOwnerName(name);
        newOwner.setPhoneNumber(phone);
        newOwner.setOwnerEmail(email);
        newOwner.setOwnerPassword(password);
        
        try {
            if (ownerDAO.register(newOwner)) {
                response.sendRedirect("OwnerLogin.jsp?registered=true");
            } else {
                throw new SQLException("Registration statement failed execution.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Database error: " + e.getMessage());
            request.getRequestDispatcher("OwnerRegister.jsp").forward(request, response);
        }
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("OwnerRegister.jsp").forward(request, response);
    }
}