/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets.owner;

import dao.WithdrawalDAO;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import rent.bean.OwnerBean;

public class OwnerRequestWithdrawServlet extends HttpServlet {

    private final WithdrawalDAO withdrawalDAO = new WithdrawalDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedOwner") == null) {
            response.sendRedirect("OwnerLogin.jsp");
            return;
        }
        OwnerBean owner = (OwnerBean) session.getAttribute("loggedOwner");

        // Must have bank details on file before they can request a withdrawal
        if (owner.getBankName() == null || owner.getBankName().trim().isEmpty()
                || owner.getBankAccNumber() == null || owner.getBankAccNumber().trim().isEmpty()) {
            response.sendRedirect("OwnerDashboardServlet?withdrawError="
                    + java.net.URLEncoder.encode("Please add your bank details in Edit Profile before withdrawing.", "UTF-8"));
            return;
        }

        double amount;
        try {
            amount = Double.parseDouble(request.getParameter("amount"));
        } catch (NumberFormatException e) {
            response.sendRedirect("OwnerDashboardServlet?withdrawError="
                    + java.net.URLEncoder.encode("Invalid amount.", "UTF-8"));
            return;
        }

        try {
            String withdrawId = withdrawalDAO.requestWithdrawal(owner.getOwnerId(), amount);
            if (withdrawId == null) {
                response.sendRedirect("OwnerDashboardServlet?withdrawError="
                        + java.net.URLEncoder.encode("Amount exceeds your available balance.", "UTF-8"));
            } else {
                response.sendRedirect("OwnerDashboardServlet?withdrawRequested=true");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("OwnerDashboardServlet?withdrawError="
                    + java.net.URLEncoder.encode("Database error: " + e.getMessage(), "UTF-8"));
        }
    }
}