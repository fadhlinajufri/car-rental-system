/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets.owner;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import rent.bean.OwnerBean;
import dao.OwnerDAO;

public class OwnerLoginServlet extends HttpServlet {
    private final OwnerDAO ownerDAO = new OwnerDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String email = request.getParameter("ownerEmail");
        String password = request.getParameter("ownerPassword");

        OwnerBean owner = ownerDAO.login(email, password);

        if (owner != null) {
            HttpSession session = request.getSession();
            session.setAttribute("loggedOwner", owner);
            response.sendRedirect("OwnerDashboardServlet");
        } else {
            request.setAttribute("error", "Invalid email or password.");
            request.getRequestDispatcher("OwnerLogin.jsp").forward(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("OwnerLogin.jsp").forward(request, response);
    }
}