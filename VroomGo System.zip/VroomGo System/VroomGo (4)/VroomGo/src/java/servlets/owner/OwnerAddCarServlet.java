package servlets.owner;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import javax.servlet.http.Part;
import rent.bean.CarBean;
import rent.bean.OwnerBean;
import dao.CarDAO;

public class OwnerAddCarServlet extends HttpServlet {

    private static final List<String> ALLOWED_EXTENSIONS =
            Arrays.asList(".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp");

    private final CarDAO carDAO = new CarDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedOwner") == null) {
            response.sendRedirect("OwnerLogin.jsp");
            return;
        }
        request.getRequestDispatcher("OwnerAddCar.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedOwner") == null) {
            response.sendRedirect("OwnerLogin.jsp");
            return;
        }

        OwnerBean owner = (OwnerBean) session.getAttribute("loggedOwner");
        String ownerId     = owner.getOwnerId();
        String plateNumber = request.getParameter("plateNumber");
        String carModel    = request.getParameter("carModel");
        String carColour   = request.getParameter("carColour");
        String rentalRate  = request.getParameter("rentalRate");

        String imageFileName = "default.png";
        Part filePart = request.getPart("carImage");

        if (filePart != null && filePart.getSize() > 0) {
            String originalName = filePart.getSubmittedFileName();

            if (originalName == null || !originalName.contains(".")) {
                request.setAttribute("error", "Invalid file name.");
                request.getRequestDispatcher("OwnerAddCar.jsp").forward(request, response);
                return;
            }

            String extension = originalName.substring(originalName.lastIndexOf(".")).toLowerCase();

            if (!ALLOWED_EXTENSIONS.contains(extension)) {
                request.setAttribute("error",
                        "Invalid image file type. Allowed: " + ALLOWED_EXTENSIONS);
                request.getRequestDispatcher("OwnerAddCar.jsp").forward(request, response);
                return;
            }

            imageFileName = "car_" + System.currentTimeMillis() + extension;

            String uploadPath = "C:/VroomGoUploads/cars";
            File uploadDir = new File(uploadPath);
            if (!uploadDir.exists()) uploadDir.mkdirs();

            File targetFile = new File(uploadDir, imageFileName);
            try (InputStream input = filePart.getInputStream()) {
                Files.copy(input, targetFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
            }
        }

        CarBean car = new CarBean();
        car.setOwnerId(ownerId);
        car.setPlateNumber(plateNumber);
        car.setCarModel(carModel);
        car.setCarColour(carColour);
        car.setRentalRate(Double.parseDouble(rentalRate));
        car.setCarImage(imageFileName);

        try {
            carDAO.addCar(car);
            response.sendRedirect("OwnerDashboardServlet?added=true");
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Database error: " + e.getMessage());
            request.getRequestDispatcher("OwnerAddCar.jsp").forward(request, response);
        }
    }
}