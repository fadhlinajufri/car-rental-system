/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets.owner;

import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import dao.CarDAO;

public class OwnerDeleteCarServlet extends HttpServlet {

    private final CarDAO carDAO = new CarDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedOwner") == null) {
            response.sendRedirect("OwnerLogin.jsp");
            return;
        }

        String carId = request.getParameter("carId");
        try {
            boolean deleted = carDAO.softDeleteCar(carId);
            if (!deleted) {
                response.sendRedirect("OwnerDashboardServlet?deleteError=true");
                return;
            }
            response.sendRedirect("OwnerDashboardServlet?deleted=true");

        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("OwnerDashboardServlet?deleteError=true");
        }
    }
}