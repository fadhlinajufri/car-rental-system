/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets.owner;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import rent.bean.CarBean;
import rent.bean.OwnerBean;
import dao.CarDAO;
public class OwnerDashboardServlet extends HttpServlet {
    private final CarDAO carDAO = new CarDAO();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedOwner") == null) {
            response.sendRedirect("OwnerLogin.jsp");
            return;
        }
        OwnerBean owner = (OwnerBean) session.getAttribute("loggedOwner");
        List<CarBean> carList = carDAO.getCarsByOwner(owner.getOwnerId());

        int totalCars = carList.size();
        int availableCars = 0;
        int rentedCars = 0;
        for (CarBean car : carList) {
            if ("Available".equals(car.getStatus())) availableCars++;
            else if ("Rented".equals(car.getStatus())) rentedCars++;
        }
        double totalEarnings = carDAO.getOwnerEarnings(owner.getOwnerId());
        request.setAttribute("carList", carList);
        request.setAttribute("totalCars", totalCars);
        request.setAttribute("availableCars", availableCars);
        request.setAttribute("rentedCars", rentedCars);
        request.setAttribute("totalEarnings", totalEarnings);
        request.getRequestDispatcher("OwnerDashboard.jsp").forward(request, response);
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}