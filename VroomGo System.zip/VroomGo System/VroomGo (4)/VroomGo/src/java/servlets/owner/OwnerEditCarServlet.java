/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets.owner;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import rent.bean.CarBean;
import dao.CarDAO;

public class OwnerEditCarServlet extends HttpServlet {

    private final CarDAO carDAO = new CarDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedOwner") == null) {
            response.sendRedirect("OwnerLogin.jsp");
            return;
        }

        String carId = request.getParameter("carId");
        try {
            CarBean car = carDAO.getCarById(carId);
            if (car != null) {
                request.setAttribute("car", car);
            }
            request.getRequestDispatcher("OwnerEditCar.jsp").forward(request, response);

        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("OwnerDashboardServlet");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedOwner") == null) {
            response.sendRedirect("OwnerLogin.jsp");
            return;
        }

        String carId       = request.getParameter("carId");
        String plateNumber  = request.getParameter("plateNumber");
        String carModel     = request.getParameter("carModel");
        String carColour    = request.getParameter("carColour");
        String rentalRate   = request.getParameter("rentalRate");
        String status       = request.getParameter("status");
        String oldImage     = request.getParameter("oldImage");

        String imageFileName = oldImage;
        Part filePart = request.getPart("carImage");

        if (filePart != null && filePart.getSize() > 0) {
            String originalName = filePart.getSubmittedFileName();
            String extension = originalName.substring(originalName.lastIndexOf("."));
            imageFileName = "car_" + System.currentTimeMillis() + extension;

            String uploadPath = getServletContext().getRealPath("/images/cars");
            File uploadDir = new File(uploadPath);
            if (!uploadDir.exists()) uploadDir.mkdirs();

            File destFile = new File(uploadDir, imageFileName);

            try (java.io.InputStream input = filePart.getInputStream();
                 java.io.OutputStream output = new java.io.FileOutputStream(destFile)) {
                byte[] buffer = new byte[4096];
                int bytesRead;
                while ((bytesRead = input.read(buffer)) != -1) {
                    output.write(buffer, 0, bytesRead);
                }
            }
        }

        CarBean car = new CarBean();
        car.setCarId(carId);
        car.setPlateNumber(plateNumber);
        car.setCarModel(carModel);
        car.setCarColour(carColour);
        car.setRentalRate(Double.parseDouble(rentalRate));
        car.setCarImage(imageFileName);
        car.setStatus(status);

        try {
            carDAO.updateCarByOwner(car);
            response.sendRedirect("OwnerDashboardServlet?updated=true");

        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Database error: " + e.getMessage());
            request.getRequestDispatcher("OwnerEditCar.jsp").forward(request, response);
        }
    }
}