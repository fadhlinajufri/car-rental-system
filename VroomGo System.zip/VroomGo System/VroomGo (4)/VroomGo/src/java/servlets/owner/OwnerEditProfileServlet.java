/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets.owner;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import rent.bean.OwnerBean;
import dao.OwnerDAO;
public class OwnerEditProfileServlet extends HttpServlet {
    private final OwnerDAO ownerDAO = new OwnerDAO();
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedOwner") == null) {
            response.sendRedirect("OwnerLogin.jsp");
            return;
        }
        request.getRequestDispatcher("OwnerEditProfile.jsp").forward(request, response);
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedOwner") == null) {
            response.sendRedirect("OwnerLogin.jsp");
            return;
        }
        OwnerBean owner = (OwnerBean) session.getAttribute("loggedOwner");
        String ownerName    = request.getParameter("ownerName");
        String phoneNumber  = request.getParameter("phoneNumber");
        String ownerEmail   = request.getParameter("ownerEmail");
        String newPassword  = request.getParameter("newPassword");
        String currentPassword = request.getParameter("currentPassword");
        String bankName      = request.getParameter("bankName");
        String bankAccNumber = request.getParameter("bankAccNumber");
        
        OwnerBean dbOwner = ownerDAO.getOwnerById(owner.getOwnerId());
        if (dbOwner == null || !dbOwner.getOwnerPassword().equals(currentPassword)) {
            request.setAttribute("error", "Current password is incorrect.");
            request.getRequestDispatcher("OwnerEditProfile.jsp").forward(request, response);
            return;
        }
        if (ownerDAO.isEmailDuplicateForOther(ownerEmail, owner.getOwnerId())) {
            request.setAttribute("error", "Email is already used by another account.");
            request.getRequestDispatcher("OwnerEditProfile.jsp").forward(request, response);
            return;
        }
        
        String passwordToSave = (newPassword != null && !newPassword.trim().isEmpty())
                ? newPassword : dbOwner.getOwnerPassword();
        
        owner.setOwnerName(ownerName);
        owner.setPhoneNumber(phoneNumber);
        owner.setOwnerEmail(ownerEmail);
        owner.setOwnerPassword(passwordToSave);
        owner.setBankName(bankName);
        owner.setBankAccNumber(bankAccNumber);
        
        if (ownerDAO.updateProfile(owner)) {
            session.setAttribute("loggedOwner", owner);
            response.sendRedirect("OwnerDashboardServlet?profileUpdated=true");
        } else {
            request.setAttribute("error", "Failed to update profile statistics.");
            request.getRequestDispatcher("OwnerEditProfile.jsp").forward(request, response);
        }
    }
}