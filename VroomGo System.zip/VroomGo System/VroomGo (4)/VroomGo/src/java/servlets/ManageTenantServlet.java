package servlets;

import java.io.IOException;
import java.sql.*;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import rent.bean.TenantBean;
import util.DBConnection;

public class ManageTenantServlet extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedAdmin") == null) {
            response.sendRedirect("AdminLogin.jsp");
            return;
        }
        
        String action = request.getParameter("action");
        if ("delete".equals(action)) {
            deleteTenant(request.getParameter("tenantId"), response);
            return;
        }
        
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            String sql = "SELECT * FROM Tenant ORDER BY tenantId";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            List<TenantBean> tenantList = new ArrayList<>();
            while (rs.next()) {
                TenantBean tenant = new TenantBean();
                tenant.setTenantId(rs.getString("tenantId"));
                tenant.setTenantName(rs.getString("tenantName"));
                tenant.setPhoneNumber(rs.getString("phoneNumber"));
                tenant.setLicenseNum(rs.getString("licenseNum"));
                tenant.setTenantEmail(rs.getString("tenantEmail"));
                tenantList.add(tenant);
            }
            request.setAttribute("tenantList", tenantList);
            request.getRequestDispatcher("ManageTenant.jsp").forward(request, response);
            
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Database error: " + e.getMessage());
            request.getRequestDispatcher("ManageTenant.jsp").forward(request, response);
        } finally {
            DBConnection.closeConnection(conn);
        }
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedAdmin") == null) {
            response.sendRedirect("AdminLogin.jsp");
            return;
        }
        
        String tenantId    = request.getParameter("tenantId");
        String tenantName  = request.getParameter("tenantName");
        String phoneNumber = request.getParameter("phoneNumber");
        String licenseNum  = request.getParameter("licenseNum");
        String tenantEmail = request.getParameter("tenantEmail");
        
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            String sql = "UPDATE Tenant SET tenantName=?, phoneNumber=?, licenseNum=?, tenantEmail=? WHERE tenantId=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, tenantName);
            ps.setString(2, phoneNumber);
            ps.setString(3, licenseNum);
            ps.setString(4, tenantEmail);
            ps.setString(5, tenantId);
            ps.executeUpdate();
            response.sendRedirect("ManageTenantServlet?updated=true");
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("ManageTenantServlet?error=true");
        } finally {
            DBConnection.closeConnection(conn);
        }
    }
    private void deleteTenant(String tenantId, HttpServletResponse response) throws IOException {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            String checkSql = "SELECT COUNT(*) FROM RentDetails WHERE tenantId = ?";
            PreparedStatement checkPs = conn.prepareStatement(checkSql);
            checkPs.setString(1, tenantId);
            ResultSet rs = checkPs.executeQuery();
            rs.next();
            
            if (rs.getInt(1) > 0) {
                response.sendRedirect("ManageTenantServlet?deleteError=true");
                return;
            }
            
            String sql = "DELETE FROM Tenant WHERE tenantId = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, tenantId);
            ps.executeUpdate();
            response.sendRedirect("ManageTenantServlet?deleted=true");
            
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("ManageTenantServlet?deleteError=true");
        } finally {
            DBConnection.closeConnection(conn);
        }
    }
}