package servlets;
import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import dao.AdminDAO;
import rent.bean.AdminBean;

public class AdminAddAdminServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedAdmin") == null) {
            response.sendRedirect("AdminLogin.jsp");
            return;
        }
        request.getRequestDispatcher("AdminAddAdmin.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedAdmin") == null) {
            response.sendRedirect("AdminLogin.jsp");
            return;
        }

        String adminName     = request.getParameter("adminName");
        String adminEmail    = request.getParameter("adminEmail");
        String adminPassword = request.getParameter("adminPassword");

        AdminDAO adminDAO = new AdminDAO();

        try {
            if (adminDAO.isEmailTaken(adminEmail)) {
                request.setAttribute("error", "Email is already registered.");
                request.getRequestDispatcher("AdminAddAdmin.jsp").forward(request, response);
                return;
            }

            if (adminDAO.isPasswordTaken(adminPassword)) {
                request.setAttribute("error", "This password is already in use. Please choose a different one.");
                request.getRequestDispatcher("AdminAddAdmin.jsp").forward(request, response);
                return;
            }

            String adminId = adminDAO.generateUniqueAdminId();

            AdminBean admin = new AdminBean();
            admin.setAdminId(adminId);
            admin.setAdminName(adminName);
            admin.setAdminEmail(adminEmail);
            admin.setAdminPassword(adminPassword);
            admin.setCreatedAt(new Timestamp(System.currentTimeMillis()));

            adminDAO.addAdmin(admin);

            response.sendRedirect("AdminAddAdminServlet?added=true");

        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Database error: " + e.getMessage());
            request.getRequestDispatcher("AdminAddAdmin.jsp").forward(request, response);
        }
    }
}