package servlets;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import dao.AdminDAO;
import rent.bean.AdminBean;

public class AdminEditProfileServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedAdmin") == null) {
            response.sendRedirect("AdminLogin.jsp");
            return;
        }
        request.getRequestDispatcher("AdminEditProfile.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedAdmin") == null) {
            response.sendRedirect("AdminLogin.jsp");
            return;
        }

        AdminBean admin = (AdminBean) session.getAttribute("loggedAdmin");
        String adminId = admin.getAdminId();

        String adminName       = request.getParameter("adminName");
        String adminEmail      = request.getParameter("adminEmail");
        String currentPassword = request.getParameter("currentPassword");
        String newPassword     = request.getParameter("newPassword");

        AdminDAO adminDAO = new AdminDAO();

        try {
            String storedPassword = adminDAO.getPasswordById(adminId);

            if (storedPassword == null) {
                request.setAttribute("error", "Admin account not found.");
                request.getRequestDispatcher("AdminEditProfile.jsp").forward(request, response);
                return;
            }

            if (!storedPassword.equals(currentPassword)) {
                request.setAttribute("error", "Current password is incorrect.");
                request.getRequestDispatcher("AdminEditProfile.jsp").forward(request, response);
                return;
            }

            if (adminDAO.isEmailTakenByOther(adminEmail, adminId)) {
                request.setAttribute("error", "Email is already used by another admin.");
                request.getRequestDispatcher("AdminEditProfile.jsp").forward(request, response);
                return;
            }

            String passwordToSave =
                    (newPassword != null && !newPassword.trim().isEmpty())
                    ? newPassword
                    : storedPassword;

            admin.setAdminName(adminName);
            admin.setAdminEmail(adminEmail);
            admin.setAdminPassword(passwordToSave);

            adminDAO.updateAdminProfile(admin);

            session.setAttribute("loggedAdmin", admin);

            response.sendRedirect("AdminDashboardServlet?profileUpdated=true");

        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Database error: " + e.getMessage());
            request.getRequestDispatcher("AdminEditProfile.jsp").forward(request, response);
        }
    }
}