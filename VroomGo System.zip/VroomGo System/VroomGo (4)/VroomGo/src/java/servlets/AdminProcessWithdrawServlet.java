/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

import dao.WithdrawalDAO;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.*;

public class AdminProcessWithdrawServlet extends HttpServlet {

    private final WithdrawalDAO withdrawalDAO = new WithdrawalDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedAdmin") == null) {
            response.sendRedirect("AdminLogin.jsp");
            return;
        }

        String withdrawId = request.getParameter("withdrawId");
        String action = request.getParameter("action"); // "approve", "decline", "pay"
        String remarks = request.getParameter("remarks");

        try {
            boolean success;
            switch (action == null ? "" : action) {
                case "approve":
                    success = withdrawalDAO.approve(withdrawId);
                    break;
                case "decline":
                    success = withdrawalDAO.decline(withdrawId, remarks);
                    break;
                case "pay":
                    success = withdrawalDAO.markAsPaid(withdrawId);
                    break;
                default:
                    success = false;
            }

            if (success) {
                response.sendRedirect("ManageWithdrawServlet?withdrawProcessed=true");
            } else {
                response.sendRedirect("ManageWithdrawServlet?withdrawError="
                        + java.net.URLEncoder.encode("Could not process request (it may have already been handled).", "UTF-8"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("ManageWithdrawServlet?withdrawError="
                    + java.net.URLEncoder.encode("Database error: " + e.getMessage(), "UTF-8"));
        }
    }
}