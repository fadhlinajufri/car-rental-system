package servlets;

import java.io.IOException;
import java.sql.*;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import rent.bean.OwnerBean;
import util.DBConnection;

public class ManageOwnerServlet extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedAdmin") == null) {
            response.sendRedirect("AdminLogin.jsp");
            return;
        }
        
        String action = request.getParameter("action");
        
        if ("delete".equals(action)) {
            String ownerId = request.getParameter("ownerId");
            deleteOwner(ownerId, response);
            return;
        }
        
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            String sql = "SELECT * FROM Owner ORDER BY ownerId";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            
            List<OwnerBean> ownerList = new ArrayList<>();
            while (rs.next()) {
                OwnerBean owner = new OwnerBean();
                owner.setOwnerId(rs.getString("ownerId"));
                owner.setOwnerName(rs.getString("ownerName"));
                owner.setPhoneNumber(rs.getString("phoneNumber"));
                owner.setOwnerEmail(rs.getString("ownerEmail"));
                ownerList.add(owner);
            }
            
            request.setAttribute("ownerList", ownerList);
            request.getRequestDispatcher("ManageOwner.jsp").forward(request, response);
            
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Database error: " + e.getMessage());
            request.getRequestDispatcher("ManageOwner.jsp").forward(request, response);
        } finally {
            DBConnection.closeConnection(conn);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedAdmin") == null) {
            response.sendRedirect("AdminLogin.jsp");
            return;
        }
        
        String ownerId = request.getParameter("ownerId");
        String ownerName = request.getParameter("ownerName");
        String phoneNumber = request.getParameter("phoneNumber");
        String ownerEmail = request.getParameter("ownerEmail");

        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            String sql = "UPDATE Owner SET ownerName=?, phoneNumber=?, ownerEmail=? WHERE ownerId=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, ownerName);
            ps.setString(2, phoneNumber);
            ps.setString(3, ownerEmail);
            ps.setString(4, ownerId);
            ps.executeUpdate();
            response.sendRedirect("ManageOwnerServlet?updated=true");
            
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("ManageOwnerServlet?error=true");
        } finally {
            DBConnection.closeConnection(conn);
        }
    }
    
    private void deleteOwner(String ownerId, HttpServletResponse response) throws IOException {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            
            String checkSql = "SELECT COUNT(*) FROM Car WHERE ownerId = ?";
            PreparedStatement checkPs = conn.prepareStatement(checkSql);
            checkPs.setString(1, ownerId);
            ResultSet rs = checkPs.executeQuery();
            rs.next();
            
            if (rs.getInt(1) > 0) {
                response.sendRedirect("ManageOwnerServlet?deleteError=true");
                return;
            }
            
            String sql = "DELETE FROM Owner WHERE ownerId = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, ownerId);
            ps.executeUpdate();
            response.sendRedirect("ManageOwnerServlet?deleted=true");
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("ManageOwnerServlet?deleteError=true");
        } finally {
            DBConnection.closeConnection(conn);
        }
    }
}