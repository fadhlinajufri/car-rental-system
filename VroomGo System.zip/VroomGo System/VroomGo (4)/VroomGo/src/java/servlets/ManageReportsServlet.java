package servlets;

import dao.ReportDAO;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.*;

public class ManageReportsServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("loggedAdmin") == null) {
            response.sendRedirect("AdminLogin.jsp");
            return;
        }

        try {

            ReportDAO dao = new ReportDAO();

            request.setAttribute("topOwners", dao.getTopOwners());
            request.setAttribute("topCars", dao.getTopCars());
            request.setAttribute("totalRevenue", dao.getTotalRevenue());
            

            request.getRequestDispatcher("ManageReports.jsp")
                   .forward(request, response);

        } catch (Exception e) {

            e.printStackTrace();

            request.setAttribute("error",
                    "Unable to generate report.");

            request.getRequestDispatcher("ManageReports.jsp")
                   .forward(request, response);
        }
    }
}