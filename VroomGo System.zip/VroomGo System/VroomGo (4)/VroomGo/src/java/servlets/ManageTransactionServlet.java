package servlets;

import java.io.IOException;
import java.sql.*;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import rent.bean.TransactionBean;
import util.DBConnection;


public class ManageTransactionServlet extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedAdmin") == null) {
            response.sendRedirect("AdminLogin.jsp");
            return;
        }
        
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            String sql = "SELECT * FROM Transactions ORDER BY transactionId";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            
            List<TransactionBean> txnList = new ArrayList<>();
            while (rs.next()) {
                TransactionBean txn = new TransactionBean();
                txn.setTransactionId(rs.getString("transactionId"));
                txn.setRentId(rs.getString("rentId"));
                txn.setTransactionDate(rs.getTimestamp("transactionDate"));
                txn.setAmount(rs.getDouble("amount"));
                txn.setPaymentMethod(rs.getString("paymentMethod"));
                txn.setTransactionStatus(rs.getString("transactionStatus"));
                txnList.add(txn);
            }
            request.setAttribute("txnList", txnList);
            request.getRequestDispatcher("ManageTransaction.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Database error: " + e.getMessage());
            request.getRequestDispatcher("ManageTransaction.jsp").forward(request, response);
        } finally {
            DBConnection.closeConnection(conn);
        }
    }
}