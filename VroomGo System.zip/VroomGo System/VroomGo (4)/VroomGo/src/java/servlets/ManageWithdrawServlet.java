package servlets;
import dao.WithdrawalDAO;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.*;
public class ManageWithdrawServlet extends HttpServlet {
    private final WithdrawalDAO withdrawalDAO = new WithdrawalDAO();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedAdmin") == null) {
            response.sendRedirect("AdminLogin.jsp");
            return;
        }
        try {
            request.setAttribute("withdrawRequests", withdrawalDAO.getAllWithdrawalsWithOwnerInfo());
            request.getRequestDispatcher("AdminManageWithdraw.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Database error: " + e.getMessage());
            request.getRequestDispatcher("AdminManageWithdraw.jsp").forward(request, response);
        }
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}