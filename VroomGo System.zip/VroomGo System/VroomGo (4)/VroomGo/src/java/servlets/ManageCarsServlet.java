/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import rent.bean.CarBean;
import dao.CarDAO;

public class ManageCarsServlet extends HttpServlet {

    private final CarDAO carDAO = new CarDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedAdmin") == null) {
            response.sendRedirect("AdminLogin.jsp");
            return;
        }
        String action = request.getParameter("action");
        if ("delete".equals(action)) {
            String carId = request.getParameter("carId");
            deleteCar(carId, request, response);
            return;
        }

        try {
            List<CarBean> carList = carDAO.getAllCarsWithOwner();
            request.setAttribute("carList", carList);
            request.getRequestDispatcher("ManageCars.jsp").forward(request, response);

        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Database error: " + e.getMessage());
            request.getRequestDispatcher("ManageCars.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedAdmin") == null) {
            response.sendRedirect("AdminLogin.jsp");
            return;
        }

        String carId       = request.getParameter("carId");
        String plateNumber = request.getParameter("plateNumber");
        String carModel    = request.getParameter("carModel");
        String carColour   = request.getParameter("carColour");
        String rentalRate  = request.getParameter("rentalRate");
        String status      = request.getParameter("status");

        CarBean car = new CarBean();
        car.setCarId(carId);
        car.setPlateNumber(plateNumber);
        car.setCarModel(carModel);
        car.setCarColour(carColour);
        car.setRentalRate(Double.parseDouble(rentalRate));
        car.setStatus(status);

        try {
            carDAO.updateCarByAdmin(car);
            response.sendRedirect("ManageCarsServlet?updated=true");
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("ManageCarsServlet?error=true");
        }
    }

    private void deleteCar(String carId, HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        try {
            boolean deleted = carDAO.softDeleteCar(carId);
            if (!deleted) {
                response.sendRedirect("ManageCarsServlet?deleteError=true");
                return;
            }
            response.sendRedirect("ManageCarsServlet?deleted=true");

        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("ManageCarsServlet?deleteError=true");
        }
    }
}