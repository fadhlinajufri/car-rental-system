/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets.tenant;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import rent.bean.TenantBean;
import rent.bean.RentDetailsBean;
import util.DBConnection;

public class TenantBookingHistoryServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedTenant") == null) {
            response.sendRedirect("TenantLogin.jsp");
            return;
        }

        TenantBean tenant = (TenantBean) session.getAttribute("loggedTenant");
        String tenantId = tenant.getTenantId();

        List<RentDetailsBean> historyList = new ArrayList<>();
        Connection conn = null;

        try {
            conn = DBConnection.getConnection();

            String sql = "SELECT rd.rentId, rd.rentDate, rd.returnDate, rd.payment, rd.status, "
                       + "c.carModel, c.plateNumber "
                       + "FROM RentDetails rd "
                       + "JOIN Car c ON rd.carId = c.carId "
                       + "WHERE rd.tenantId = ? "
                       + "ORDER BY rd.rentDate DESC";

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, tenantId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                RentDetailsBean rent = new RentDetailsBean();
                rent.setRentId(rs.getString("rentId"));
                rent.setCarModel(rs.getString("carModel"));
                rent.setPlateNum(rs.getString("plateNumber"));
                rent.setRentDate(rs.getString("rentDate"));
                rent.setReturnDate(rs.getString("returnDate"));
                rent.setPayment(rs.getDouble("payment"));
                rent.setStatus(rs.getString("status"));
                historyList.add(rent);
            }

            request.setAttribute("historyList", historyList);
            request.getRequestDispatcher("TenantBookingHistory.jsp").forward(request, response);

        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Database error: " + e.getMessage());
            request.getRequestDispatcher("TenantBookingHistory.jsp").forward(request, response);
        } finally {
            DBConnection.closeConnection(conn);
        }
    }
}