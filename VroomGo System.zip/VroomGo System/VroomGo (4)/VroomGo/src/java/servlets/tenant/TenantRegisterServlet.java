package servlets.tenant;


import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import util.DBConnection;
public class TenantRegisterServlet extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String name     = request.getParameter("tenantName");
        String phone    = request.getParameter("phoneNumber");
        String license  = request.getParameter("licenseNum");
        String email    = request.getParameter("tenantEmail");
        String password = request.getParameter("tenantPassword");
        String confirm  = request.getParameter("confirmPassword");
        
        if (!password.equals(confirm)) {
            request.setAttribute("error", "Passwords do not match.");
            request.getRequestDispatcher("TenantRegister.jsp").forward(request, response);
            return;
        }
        
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            
            // Check email uniqueness
            if (isDuplicate(conn, "tenantEmail", email)) {
                request.setAttribute("error", "Email is already registered.");
                request.getRequestDispatcher("TenantRegister.jsp").forward(request, response);
                return;
            }
            
            // Check phone number uniqueness
            if (isDuplicate(conn, "phoneNumber", phone)) {
                request.setAttribute("error", "Phone number is already registered.");
                request.getRequestDispatcher("TenantRegister.jsp").forward(request, response);
                return;
            }
            
            // Check license number uniqueness
            if (isDuplicate(conn, "licenseNum", license)) {
                request.setAttribute("error", "License number is already registered.");
                request.getRequestDispatcher("TenantRegister.jsp").forward(request, response);
                return;
            }
            
            // Check password uniqueness
            if (isDuplicate(conn, "tenantPassword", password)) {
                request.setAttribute("error", "This password is already in use. Please choose a different one.");
                request.getRequestDispatcher("TenantRegister.jsp").forward(request, response);
                return;
            }
            
            String tenantId = generateUniqueTenantId(conn);
            
            String sql = "INSERT INTO Tenant (tenantId, tenantName, phoneNumber, licenseNum, tenantEmail, tenantPassword, createdAt) "
                       + "VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, tenantId);
            ps.setString(2, name);
            ps.setString(3, phone);
            ps.setString(4, license);
            ps.setString(5, email);
            ps.setString(6, password);
            ps.setTimestamp(7, new Timestamp(System.currentTimeMillis()));
            ps.executeUpdate();
            
            response.sendRedirect("TenantLogin.jsp?registered=true");
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Database error: " + e.getMessage());
            request.getRequestDispatcher("TenantRegister.jsp").forward(request, response);
        } finally {
            DBConnection.closeConnection(conn);
        }
    }
   
    private String generateUniqueTenantId(Connection conn) throws SQLException {
        String maxIdSql = "SELECT MAX(CAST(SUBSTR(tenantId, 2) AS INT)) AS maxId FROM Tenant";
        int nextNum = 1;
        try (PreparedStatement maxIdPs = conn.prepareStatement(maxIdSql);
             ResultSet maxIdRs = maxIdPs.executeQuery()) {
            if (maxIdRs.next()) {
                int currentMax = maxIdRs.getInt("maxId");
                if (!maxIdRs.wasNull()) {
                    nextNum = currentMax + 1;
                }
            }
        }

        String checkSql = "SELECT COUNT(*) FROM Tenant WHERE tenantId = ?";
        String candidateId = String.format("T%03d", nextNum);

        while (true) {
            try (PreparedStatement checkPs = conn.prepareStatement(checkSql)) {
                checkPs.setString(1, candidateId);
                try (ResultSet checkRs = checkPs.executeQuery()) {
                    checkRs.next();
                    if (checkRs.getInt(1) == 0) {
                        break; // candidateId is free
                    }
                }
            }
            nextNum++;
            candidateId = String.format("T%03d", nextNum);
        }

        return candidateId;
    }

    /* Checks whether a value already exists in the given column of the Tenant table. */
    private boolean isDuplicate(Connection conn, String columnName, String value) throws SQLException {
        String sql = "SELECT 1 FROM Tenant WHERE " + columnName + " = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, value);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("TenantRegister.jsp").forward(request, response);
    }
}