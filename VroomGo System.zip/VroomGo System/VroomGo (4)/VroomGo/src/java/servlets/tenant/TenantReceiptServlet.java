/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets.tenant;

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import rent.bean.TenantBean;
import util.DBConnection;
public class TenantReceiptServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedTenant") == null) {
            response.sendRedirect("TenantLogin.jsp");
            return;
        }

        TenantBean tenant = (TenantBean) session.getAttribute("loggedTenant");
        String tenantId = tenant.getTenantId();
        String transactionId = request.getParameter("transactionId");

        Connection conn = null;
        try {
            conn = DBConnection.getConnection();

            String sql = "SELECT t.transactionId, t.transactionDate, t.amount, t.paymentMethod, t.transactionStatus, "
                       + "rd.rentId, rd.rentDate, rd.returnDate, rd.tenantId, "
                       + "c.carModel, c.plateNumber "
                       + "FROM Transactions t "
                       + "JOIN RentDetails rd ON t.rentId = rd.rentId "
                       + "JOIN Car c ON rd.carId = c.carId "
                       + "WHERE t.transactionId = ?";

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, transactionId);
            ResultSet rs = ps.executeQuery();

            if (!rs.next() || !tenantId.equals(rs.getString("tenantId"))) {
                request.setAttribute("error", "Receipt not found.");
                request.getRequestDispatcher("TenantDashboardServlet").forward(request, response);
                return;
            }

            request.setAttribute("transactionId", rs.getString("transactionId"));
            request.setAttribute("transactionDate", rs.getTimestamp("transactionDate"));
            request.setAttribute("amount", rs.getDouble("amount"));
            request.setAttribute("paymentMethod", rs.getString("paymentMethod"));
            request.setAttribute("transactionStatus", rs.getString("transactionStatus"));
            request.setAttribute("rentId", rs.getString("rentId"));
            request.setAttribute("rentDate", rs.getString("rentDate"));
            request.setAttribute("returnDate", rs.getString("returnDate"));
            request.setAttribute("carModel", rs.getString("carModel"));
            request.setAttribute("plateNumber", rs.getString("plateNumber"));

            request.getRequestDispatcher("TenantReceipt.jsp").forward(request, response);

        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Database error: " + e.getMessage());
            request.getRequestDispatcher("TenantDashboardServlet").forward(request, response);
        } finally {
            DBConnection.closeConnection(conn);
        }
    }
}