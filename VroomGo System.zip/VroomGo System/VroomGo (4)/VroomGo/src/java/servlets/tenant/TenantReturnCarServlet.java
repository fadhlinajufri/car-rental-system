/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets.tenant;

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import util.DBConnection;

public class TenantReturnCarServlet extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedTenant") == null) {
            response.sendRedirect("TenantLogin.jsp");
            return;
        }
        String rentId = request.getParameter("rentId");
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            String getCarSql = "SELECT carId FROM RentDetails WHERE rentId = ?";
            PreparedStatement getCarPs = conn.prepareStatement(getCarSql);
            getCarPs.setString(1, rentId);
            ResultSet rs = getCarPs.executeQuery();
            
            if (rs.next()) {
                String carId = rs.getString("carId");
                
                // Mark rental as completed
                String updateRentSql = "UPDATE RentDetails SET status = 'Completed' WHERE rentId = ?";
                PreparedStatement updateRentPs = conn.prepareStatement(updateRentSql);
                updateRentPs.setString(1, rentId);
                updateRentPs.executeUpdate();
                
                // Mark car as available again
                String updateCarSql = "UPDATE Car SET status = 'Available' WHERE carId = ?";
                PreparedStatement updateCarPs = conn.prepareStatement(updateCarSql);
                updateCarPs.setString(1, carId);
                updateCarPs.executeUpdate();
            }
            response.sendRedirect("TenantDashboardServlet?returned=true");
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("TenantDashboardServlet?error=true");
        } finally {
            DBConnection.closeConnection(conn);
        }
    }
}