package servlets.tenant;

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import rent.bean.TenantBean;
import util.DBConnection;

public class TenantLoginServlet extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String email    = request.getParameter("tenantEmail");
        String password = request.getParameter("tenantPassword");
        
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            String sql = "SELECT * FROM Tenant WHERE tenantEmail = ? AND tenantPassword = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, email);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                TenantBean tenant = new TenantBean();
                tenant.setTenantId(rs.getString("tenantId"));
                tenant.setTenantName(rs.getString("tenantName"));
                tenant.setTenantEmail(rs.getString("tenantEmail"));
                tenant.setPhoneNumber(rs.getString("phoneNumber"));
                tenant.setLicenseNum(rs.getString("licenseNum"));
                
                HttpSession session = request.getSession();
                session.setAttribute("loggedTenant", tenant);
                response.sendRedirect("TenantDashboardServlet");
            } else {
                request.setAttribute("error", "Invalid email or password.");
                request.getRequestDispatcher("TenantLogin.jsp").forward(request, response);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Database error: " + e.getMessage());
            request.getRequestDispatcher("TenantLogin.jsp").forward(request, response);
        } finally {
            DBConnection.closeConnection(conn);
        }
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("TenantLogin.jsp").forward(request, response);
    }
}