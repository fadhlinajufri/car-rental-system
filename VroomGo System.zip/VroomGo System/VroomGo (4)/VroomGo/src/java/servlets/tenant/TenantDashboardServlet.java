package servlets.tenant;

import java.io.IOException;
import java.sql.*;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import rent.bean.CarBean;
import rent.bean.RentDetailsBean;
import rent.bean.TenantBean;
import util.DBConnection;

public class TenantDashboardServlet extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedTenant") == null) {
            response.sendRedirect("TenantLogin.jsp");
            return;
        }
        
        TenantBean tenant = (TenantBean) session.getAttribute("loggedTenant");
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            String carSql = "SELECT c.*, o.ownerName FROM Car c "
                       + "JOIN Owner o ON c.ownerId = o.ownerId "
                       + "WHERE c.status = 'Available'";
            PreparedStatement carPs = conn.prepareStatement(carSql);
            ResultSet carRs = carPs.executeQuery();
            
            
            List<CarBean> carList = new ArrayList<>();
            while (carRs.next()) {
                CarBean car = new CarBean();
                car.setCarId(carRs.getString("carId"));
                car.setPlateNumber(carRs.getString("plateNumber"));
                car.setCarModel(carRs.getString("carModel"));
                car.setCarColour(carRs.getString("carColour"));
                car.setRentalRate(carRs.getDouble("rentalRate"));
                car.setStatus(carRs.getString("status"));
                car.setOwnerName(carRs.getString("ownerName"));
                car.setCarImage(carRs.getString("carImage"));
                carList.add(car);
            }
            request.setAttribute("carList", carList);
            String bookingSql = "SELECT r.*, c.carModel, c.plateNumber FROM RentDetails r "
                       + "JOIN Car c ON r.carId = c.carId "
                       + "WHERE r.tenantId = ? AND r.status IN('Confirmed', 'Pending') "
                       + "ORDER BY r.rentId";
            PreparedStatement bookingPs = conn.prepareStatement(bookingSql);
            bookingPs.setString(1, tenant.getTenantId());
            ResultSet bookingRs = bookingPs.executeQuery();
            
            List<RentDetailsBean> bookingList = new ArrayList<>();
            while (bookingRs.next()) {
                RentDetailsBean rent = new RentDetailsBean();
                rent.setRentId(bookingRs.getString("rentId"));
                rent.setCarModel(bookingRs.getString("carModel"));
                rent.setPlateNum(bookingRs.getString("plateNumber"));
                rent.setRentDate(bookingRs.getDate("rentDate").toString());
                rent.setReturnDate(bookingRs.getDate("returnDate").toString());
                rent.setPayment(bookingRs.getDouble("payment"));
                rent.setStatus(bookingRs.getString("status"));
                bookingList.add(rent);
            }
            request.setAttribute("bookingList", bookingList);
            request.getRequestDispatcher("TenantDashboard.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Database error: " + e.getMessage());
            request.getRequestDispatcher("TenantDashboard.jsp").forward(request, response);
        } finally {
            DBConnection.closeConnection(conn);
        }
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}