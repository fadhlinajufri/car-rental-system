package servlets.tenant;

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import rent.bean.TenantBean;
import util.DBConnection;

public class TenantConfirmBookingServlet extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedTenant") == null) {
            response.sendRedirect("TenantLogin.jsp");
            return;
        }
        
        TenantBean tenant = (TenantBean) session.getAttribute("loggedTenant");
        String tenantId  = tenant.getTenantId();
        String carId     = request.getParameter("carId");
        String rentDate  = request.getParameter("rentDate");
        String returnDate = request.getParameter("returnDate");
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            
            
            
            String carSql = "SELECT rentalRate FROM Car WHERE carId = ?";
            PreparedStatement carPs = conn.prepareStatement(carSql);
            carPs.setString(1, carId);
            ResultSet carRs = carPs.executeQuery();
            carRs.next();
            double rentalRate = carRs.getDouble("rentalRate");
            
            
            Date d1 = Date.valueOf(rentDate);
            Date d2 = Date.valueOf(returnDate);
            long days = (d2.getTime() - d1.getTime()) / (1000 * 60 * 60 * 24);
            if (days <= 0) {
                request.setAttribute("error", "Return date must be after rent date.");
                request.setAttribute("carId", carId);
                request.getRequestDispatcher("TenantConfirmBooking.jsp").forward(request, response);
                return;
            }
            double payment = days * rentalRate;
            
            String maxSql = "SELECT MAX(CAST(SUBSTR(rentId, 2) AS INT)) FROM RentDetails";
            PreparedStatement maxPs = conn.prepareStatement(maxSql);
            ResultSet maxRs = maxPs.executeQuery();
            int nextNum = 1;
            if (maxRs.next()) {
                int currentMax = maxRs.getInt(1);
                if (!maxRs.wasNull()) {
                nextNum = currentMax + 1;
            }
           }
            String rentId = String.format("R%03d", nextNum);
            
            String sql = "INSERT INTO RentDetails (rentId, carId, tenantId, rentDate, returnDate, payment, status) "
                       + "VALUES (?, ?, ?, ?, ?, ?, 'Pending')";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, rentId);
            ps.setString(2, carId);
            ps.setString(3, tenantId);
            ps.setDate(4, d1);
            ps.setDate(5, d2);
            ps.setDouble(6, payment);
            ps.executeUpdate();
            
            String updateSql = "UPDATE Car SET status = 'Rented' WHERE carId = ?";
            PreparedStatement updatePs = conn.prepareStatement(updateSql);
            updatePs.setString(1, carId);
            updatePs.executeUpdate();

            // Redirect to payment page
            response.sendRedirect("TenantPaymentServlet?rentId=" + rentId + "&payment=" + payment);

        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Database error: " + e.getMessage());
            request.getRequestDispatcher("TenantConfirmBooking.jsp").forward(request, response);
        } finally {
            DBConnection.closeConnection(conn);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("TenantConfirmBooking.jsp").forward(request, response);
    }
}