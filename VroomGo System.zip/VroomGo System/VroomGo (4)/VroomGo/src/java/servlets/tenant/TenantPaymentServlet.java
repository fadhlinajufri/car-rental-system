
package servlets.tenant;


import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import rent.bean.TenantBean;
import util.DBConnection;
public class TenantPaymentServlet extends HttpServlet {
 
    // VroomGo service charge deducted from each owner's earnings
    private static final double SERVICE_CHARGE_RATE = 0.10; // 10%
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedTenant") == null) {
            response.sendRedirect("TenantLogin.jsp");
            return;
        }
        request.getRequestDispatcher("TenantPayment.jsp").forward(request, response);
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedTenant") == null) {
            response.sendRedirect("TenantLogin.jsp");
            return;
        }
        
        TenantBean tenant = (TenantBean) session.getAttribute("loggedTenant");
        String tenantId = tenant.getTenantId();
        
        String rentId        = request.getParameter("rentId");
        String paymentMethod = request.getParameter("paymentMethod");
        
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            
            // Verify this booking exists and belongs to the logged-in tenant,
            // and get the real amount owed 
            String checkSql = "SELECT payment, tenantId FROM RentDetails WHERE rentId = ?";
            PreparedStatement checkPs = conn.prepareStatement(checkSql);
            checkPs.setString(1, rentId);
            ResultSet checkRs = checkPs.executeQuery();
            
            if (!checkRs.next() || !tenantId.equals(checkRs.getString("tenantId"))) {
                request.setAttribute("error", "Invalid booking.");
                request.getRequestDispatcher("TenantPayment.jsp").forward(request, response);
                return;
            }
            double amount = checkRs.getDouble("payment");
            
            // Deduct the platform service charge from this specific booking's payment
            double serviceCharge = amount * SERVICE_CHARGE_RATE;
            double ownerEarning  = amount - serviceCharge;
            
            //Generate TrasactionID
            String transactionId = generateUniqueTransactionId(conn);
            
            // Insert transaction, storing the service charge and owner earning 
            String sql = "INSERT INTO Transactions (transactionId, rentId, transactionDate, amount, paymentMethod, transactionStatus, serviceCharge, ownerEarning) "
                       + "VALUES (?, ?, ?, ?, ?, 'Completed', ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, transactionId);
            ps.setString(2, rentId);
            ps.setTimestamp(3, new Timestamp(System.currentTimeMillis()));
            ps.setDouble(4, amount);
            ps.setString(5, paymentMethod);
            ps.setDouble(6, serviceCharge);
            ps.setDouble(7, ownerEarning);
            ps.executeUpdate();
            
            // Update rent status
            String updateSql = "UPDATE RentDetails SET status = 'Confirmed' WHERE rentId = ?";
            PreparedStatement updatePs = conn.prepareStatement(updateSql);
            updatePs.setString(1, rentId);
            updatePs.executeUpdate();
            
            response.sendRedirect("TenantReceiptServlet?transactionId=" + transactionId);
            
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Payment error: " + e.getMessage());
            request.getRequestDispatcher("TenantPayment.jsp").forward(request, response);
        } finally {
            DBConnection.closeConnection(conn);
        }
    }
    
    /* Incrementing until a free ID is found. Avoids duplicate-key errors */
    private String generateUniqueTransactionId(Connection conn) throws SQLException {
        String maxIdSql = "SELECT MAX(CAST(SUBSTR(transactionId, 3) AS INT)) AS maxId FROM Transactions";
        int nextNum = 1;
        try (PreparedStatement maxIdPs = conn.prepareStatement(maxIdSql);
             ResultSet maxIdRs = maxIdPs.executeQuery()) {
            if (maxIdRs.next()) {
                int currentMax = maxIdRs.getInt("maxId");
                if (!maxIdRs.wasNull()) {
                    nextNum = currentMax + 1;
                }
            }
        }
 
        String checkSql = "SELECT COUNT(*) FROM Transactions WHERE transactionId = ?";
        String candidateId = String.format("TR%03d", nextNum);
 
        while (true) {
            try (PreparedStatement checkPs = conn.prepareStatement(checkSql)) {
                checkPs.setString(1, candidateId);
                try (ResultSet checkRs = checkPs.executeQuery()) {
                    checkRs.next();
                    if (checkRs.getInt(1) == 0) {
                        break; 
                    }
                }
            }
            nextNum++;
            candidateId = String.format("TR%03d", nextNum);
        }
 
        return candidateId;
    }
}
 








