/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets.tenant;

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import rent.bean.TenantBean;
import util.DBConnection;

public class TenantEditProfileServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("loggedTenant") == null) {
            response.sendRedirect("TenantLogin.jsp");
            return;
        }

        request.getRequestDispatcher("TenantEditProfile.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("loggedTenant") == null) {
            response.sendRedirect("TenantLogin.jsp");
            return;
        }

        TenantBean tenant = (TenantBean) session.getAttribute("loggedTenant");

        String tenantId = tenant.getTenantId();

        String tenantName = request.getParameter("tenantName");
        String phoneNumber = request.getParameter("phoneNumber");
        String licenseNum = request.getParameter("licenseNum");
        String tenantEmail = request.getParameter("tenantEmail");
        String currentPassword = request.getParameter("currentPassword");
        String newPassword = request.getParameter("newPassword");

        Connection conn = null;

        try {
            conn = DBConnection.getConnection();

            // Verify current password
            String verifySql = "SELECT tenantPassword FROM Tenant WHERE tenantId = ?";
            PreparedStatement verifyPs = conn.prepareStatement(verifySql);
            verifyPs.setString(1, tenantId);

            ResultSet verifyRs = verifyPs.executeQuery();

            if (!verifyRs.next()) {
                request.setAttribute("error", "Tenant not found.");
                request.getRequestDispatcher("TenantEditProfile.jsp").forward(request, response);
                return;
            }

            String storedPassword = verifyRs.getString("tenantPassword");

            if (!storedPassword.equals(currentPassword)) {
                request.setAttribute("error", "Current password is incorrect.");
                request.getRequestDispatcher("TenantEditProfile.jsp").forward(request, response);
                return;
            }

            // Check email duplication
            String checkSql = "SELECT tenantId FROM Tenant WHERE tenantEmail = ? AND tenantId <> ?";
            PreparedStatement checkPs = conn.prepareStatement(checkSql);
            checkPs.setString(1, tenantEmail);
            checkPs.setString(2, tenantId);

            ResultSet checkRs = checkPs.executeQuery();

            if (checkRs.next()) {
                request.setAttribute("error", "Email is already used by another account.");
                request.getRequestDispatcher("TenantEditProfile.jsp").forward(request, response);
                return;
            }

            // Keep old password if new password is empty
            String passwordToSave =
                    (newPassword != null && !newPassword.trim().isEmpty())
                    ? newPassword
                    : storedPassword;

            // Update tenant profile
            String updateSql =
                    "UPDATE Tenant SET tenantName=?, phoneNumber=?, licenseNum=?, tenantEmail=?, tenantPassword=? WHERE tenantId=?";

            PreparedStatement ps = conn.prepareStatement(updateSql);
            ps.setString(1, tenantName);
            ps.setString(2, phoneNumber);
            ps.setString(3, licenseNum);
            ps.setString(4, tenantEmail);
            ps.setString(5, passwordToSave);
            ps.setString(6, tenantId);

            ps.executeUpdate();

            // Update session bean
            tenant.setTenantName(tenantName);
            tenant.setPhoneNumber(phoneNumber);
            tenant.setLicenseNum(licenseNum);
            tenant.setTenantEmail(tenantEmail);

            session.setAttribute("loggedTenant", tenant);

            response.sendRedirect("TenantDashboardServlet?profileUpdated=true");

        } catch (SQLException e) {
            e.printStackTrace();

            request.setAttribute("error", "Database error: " + e.getMessage());
            request.getRequestDispatcher("TenantEditProfile.jsp").forward(request, response);

        } finally {
            DBConnection.closeConnection(conn);
        }
    }
}