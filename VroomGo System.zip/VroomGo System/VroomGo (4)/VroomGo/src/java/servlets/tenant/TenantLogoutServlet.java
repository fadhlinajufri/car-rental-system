package servlets.tenant;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.*;

public class TenantLogoutServlet extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
        response.sendRedirect("index.html");
    }
}