/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets.tenant;

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import rent.bean.TenantBean;
import util.DBConnection;

public class TenantCancelBookingServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedTenant") == null) {
            response.sendRedirect("TenantLogin.jsp");
            return;
        }

        TenantBean tenant = (TenantBean) session.getAttribute("loggedTenant");
        String tenantId = tenant.getTenantId();
        String rentId   = request.getParameter("rentId");

        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            conn.setAutoCommit(false); // both updates succeed together, or neither does

            // 1. Verify this booking belongs to the logged-in tenant and is still Pending
            String checkSql = "SELECT carId, status FROM RentDetails WHERE rentId = ? AND tenantId = ?";
            PreparedStatement checkPs = conn.prepareStatement(checkSql);
            checkPs.setString(1, rentId);
            checkPs.setString(2, tenantId);
            ResultSet rs = checkPs.executeQuery();

            if (!rs.next()) {
                conn.rollback();
                response.sendRedirect("TenantDashboardServlet?error=notfound");
                return;
            }

            String carId = rs.getString("carId");
            String currentStatus = rs.getString("status");

            if (!"Pending".equals(currentStatus)) {
                // Already paid/confirmed (or already cancelled) 
                conn.rollback();
                response.sendRedirect("TenantDashboardServlet?error=cannotcancel");
                return;
            }

            // 2. Mark booking as Cancelled
            String updateRentSql = "UPDATE RentDetails SET status = 'Cancelled' WHERE rentId = ?";
            PreparedStatement updateRentPs = conn.prepareStatement(updateRentSql);
            updateRentPs.setString(1, rentId);
            updateRentPs.executeUpdate();

            // 3. Release the car back to Available
            String updateCarSql = "UPDATE Car SET status = 'Available' WHERE carId = ?";
            PreparedStatement updateCarPs = conn.prepareStatement(updateCarSql);
            updateCarPs.setString(1, carId);
            updateCarPs.executeUpdate();

            conn.commit();
            response.sendRedirect("TenantDashboardServlet?cancelled=true");

        } catch (SQLException e) {
            e.printStackTrace();
            try { if (conn != null) conn.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            response.sendRedirect("TenantDashboardServlet?error=dberror");
        } finally {
            try { if (conn != null) conn.setAutoCommit(true); } catch (SQLException ex) { ex.printStackTrace(); }
            DBConnection.closeConnection(conn);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("TenantDashboardServlet");
    }
}