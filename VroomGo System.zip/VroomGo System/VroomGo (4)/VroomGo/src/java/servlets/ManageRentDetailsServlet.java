package servlets;

import dao.RentDetailsDAO;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import rent.bean.RentDetailsBean;

public class ManageRentDetailsServlet extends HttpServlet {

    private final RentDetailsDAO rentDetailsDAO = new RentDetailsDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedAdmin") == null) {
            response.sendRedirect("AdminLogin.jsp");
            return;
        }

        try {
            List<RentDetailsBean> rentList = rentDetailsDAO.getAllRentDetailsWithDetails();
            request.setAttribute("rentList", rentList);
            request.getRequestDispatcher("ManageRentDetails.jsp").forward(request, response);

        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Database error: " + e.getMessage());
            request.getRequestDispatcher("ManageRentDetails.jsp").forward(request, response);
        }
    }
}