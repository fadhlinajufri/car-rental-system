package servlets;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import dao.AdminDAO;
import rent.bean.AdminBean;

public class AdminLoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email    = request.getParameter("adminEmail");
        String password = request.getParameter("adminPassword");

        AdminDAO adminDAO = new AdminDAO();

        try {
            AdminBean admin = adminDAO.login(email, password);

            if (admin != null) {
                HttpSession session = request.getSession();
                session.setAttribute("loggedAdmin", admin);
                response.sendRedirect("AdminDashboardServlet");
            } else {
                request.setAttribute("error", "Invalid email or password.");
                request.getRequestDispatcher("AdminLogin.jsp").forward(request, response);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Something went wrong. Please try again later.");
            request.getRequestDispatcher("AdminLogin.jsp").forward(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("AdminLogin.jsp").forward(request, response);
    }
}