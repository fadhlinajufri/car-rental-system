
import java.sql.Connection;
import util.DBConnection;

public class TestConnection {

    public static void main(String[] args) {
        try {
            Connection con = DBConnection.getConnection();
            System.out.println("Connection SUCCESS!");
        } catch (Exception e) {
            System.out.println("Connection FAILED: " + e.getMessage());
        }
    }
}