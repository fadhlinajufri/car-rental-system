/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import rent.bean.RentDetailsBean;
import util.DBConnection;

/* Servlets should go through this class instead of writing JDBC directly */
public class RentDetailsDAO {

    /**
     * Returns every rent record joined with car, tenant, and owner info.
     * Used by the admin "manage rent details" view.
     */
    public List<RentDetailsBean> getAllRentDetailsWithDetails() throws SQLException {
        Connection conn = null;
        List<RentDetailsBean> rentList = new ArrayList<>();
        try {
            conn = DBConnection.getConnection();
            String sql = "SELECT r.*, c.carModel, c.plateNumber, t.tenantName, o.ownerName "
                       + "FROM RentDetails r "
                       + "JOIN Car c ON r.carId = c.carId "
                       + "JOIN Tenant t ON r.tenantId = t.tenantId "
                       + "JOIN Owner o ON c.ownerId = o.ownerId "
                       + "ORDER BY r.rentId";
            try (PreparedStatement ps = conn.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    rentList.add(mapRow(rs));
                }
            }
            return rentList;
        } finally {
            DBConnection.closeConnection(conn);
        }
    }

    /**
     * Fetches a single rent record (with joined details) by id, or null if it doesn't exist.
     */
    public RentDetailsBean getRentDetailsById(String rentId) throws SQLException {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            String sql = "SELECT r.*, c.carModel, c.plateNumber, t.tenantName, o.ownerName "
                       + "FROM RentDetails r "
                       + "JOIN Car c ON r.carId = c.carId "
                       + "JOIN Tenant t ON r.tenantId = t.tenantId "
                       + "JOIN Owner o ON c.ownerId = o.ownerId "
                       + "WHERE r.rentId = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, rentId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        return mapRow(rs);
                    }
                }
            }
            return null;
        } finally {
            DBConnection.closeConnection(conn);
        }
    }

    /**
     * Updates just the status of a rent record (e.g. "Ongoing" -> "Completed").
     */
    public boolean updateStatus(String rentId, String status) throws SQLException {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            String sql = "UPDATE RentDetails SET status = ? WHERE rentId = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, status);
                ps.setString(2, rentId);
                return ps.executeUpdate() > 0;
            }
        } finally {
            DBConnection.closeConnection(conn);
        }
    }

    /**
     * Deletes a rent record by id.
     */
    public boolean deleteRentDetails(String rentId) throws SQLException {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            String sql = "DELETE FROM RentDetails WHERE rentId = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, rentId);
                return ps.executeUpdate() > 0;
            }
        } finally {
            DBConnection.closeConnection(conn);
        }
    }

    private RentDetailsBean mapRow(ResultSet rs) throws SQLException {
        RentDetailsBean rent = new RentDetailsBean();
        rent.setRentId(rs.getString("rentId"));
        rent.setCarModel(rs.getString("carModel"));
        rent.setPlateNum(rs.getString("plateNumber"));
        rent.setTenantName(rs.getString("tenantName"));
        rent.setOwnerName(rs.getString("ownerName"));
        rent.setRentDate(rs.getDate("rentDate").toString());
        rent.setReturnDate(rs.getDate("returnDate") != null ? rs.getDate("returnDate").toString() : null);
        rent.setPayment(rs.getDouble("payment"));
        rent.setStatus(rs.getString("status"));
        return rent;
    }
}
