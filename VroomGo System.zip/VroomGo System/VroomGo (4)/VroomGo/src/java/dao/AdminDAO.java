/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import rent.bean.AdminBean;
import util.DBConnection;

public class AdminDAO {

    /* ---------- LOGIN ---------- */

    /**
     * Validates admin credentials.
     * Returns the AdminBean if match found, otherwise null.
     */
    public AdminBean login(String email, String password) throws SQLException {
        String sql = "SELECT * FROM Admin WHERE adminEmail = ? AND adminPassword = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, email);
            ps.setString(2, password);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    /* ---------- DUPLICATE CHECKS ---------- */

    public boolean isEmailTaken(String email) throws SQLException {
        String sql = "SELECT 1 FROM Admin WHERE adminEmail = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    /** Used for edit profile — excludes the admin's own record from the check */
    public boolean isEmailTakenByOther(String email, String excludeAdminId) throws SQLException {
        String sql = "SELECT 1 FROM Admin WHERE adminEmail = ? AND adminId <> ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            ps.setString(2, excludeAdminId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    public boolean isPasswordTaken(String password) throws SQLException {
        String sql = "SELECT 1 FROM Admin WHERE adminPassword = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, password);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    /* ---------- ID GENERATION ---------- */

    /* Incrementing until a free ID is found. This avoids duplicate-key errors caused by gaps from deleted rows */
    public String generateUniqueAdminId() throws SQLException {
        try (Connection conn = DBConnection.getConnection()) {
            String maxIdSql = "SELECT MAX(CAST(SUBSTR(adminId, 2) AS INT)) AS maxId FROM Admin";
            int nextNum = 1;

            try (PreparedStatement maxIdPs = conn.prepareStatement(maxIdSql);
                 ResultSet maxIdRs = maxIdPs.executeQuery()) {
                if (maxIdRs.next()) {
                    int currentMax = maxIdRs.getInt("maxId");
                    if (!maxIdRs.wasNull()) {
                        nextNum = currentMax + 1;
                    }
                }
            }

            String checkSql = "SELECT COUNT(*) FROM Admin WHERE adminId = ?";
            String candidateId = String.format("A%03d", nextNum);

            while (true) {
                try (PreparedStatement checkPs = conn.prepareStatement(checkSql)) {
                    checkPs.setString(1, candidateId);
                    try (ResultSet checkRs = checkPs.executeQuery()) {
                        checkRs.next();
                        if (checkRs.getInt(1) == 0) {
                            break;
                        }
                    }
                }
                nextNum++;
                candidateId = String.format("A%03d", nextNum);
            }

            return candidateId;
        }
    }

    /* ---------- CREATE ---------- */

    /**
     * Inserts a new admin. Expects adminId already set (use generateUniqueAdminId()
     * beforehand) and createdAt set by the caller, or pass null to default to now.
     */
    public boolean addAdmin(AdminBean admin) throws SQLException {
        String sql = "INSERT INTO Admin (adminId, adminName, adminEmail, adminPassword, createdAt) "
                   + "VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, admin.getAdminId());
            ps.setString(2, admin.getAdminName());
            ps.setString(3, admin.getAdminEmail());
            ps.setString(4, admin.getAdminPassword());

            Timestamp createdAt = admin.getCreatedAt() != null
                    ? admin.getCreatedAt()
                    : new Timestamp(System.currentTimeMillis());
            ps.setTimestamp(5, createdAt);

            return ps.executeUpdate() > 0;
        }
    }

    /* ---------- READ ---------- */

    public AdminBean getAdminById(String adminId) throws SQLException {
        String sql = "SELECT * FROM Admin WHERE adminId = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, adminId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    /** Returns just the stored password for verification (used by edit profile) */
    public String getPasswordById(String adminId) throws SQLException {
        String sql = "SELECT adminPassword FROM Admin WHERE adminId = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, adminId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("adminPassword");
                }
            }
        }
        return null;
    }

    public List<AdminBean> getAllAdmins() throws SQLException {
        List<AdminBean> list = new ArrayList<>();
        String sql = "SELECT * FROM Admin ORDER BY adminId";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(mapRow(rs));
            }
        }
        return list;
    }

    /* ---------- UPDATE ---------- */

    /**
     * Updates name, email, and password. Caller decides what password to pass in
     * (e.g. keep old one if newPassword field was left blank).
     */
    public boolean updateAdminProfile(AdminBean admin) throws SQLException {
        String sql = "UPDATE Admin SET adminName = ?, adminEmail = ?, adminPassword = ? WHERE adminId = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, admin.getAdminName());
            ps.setString(2, admin.getAdminEmail());
            ps.setString(3, admin.getAdminPassword());
            ps.setString(4, admin.getAdminId());

            return ps.executeUpdate() > 0;
        }
    }

    /* ---------- DELETE ---------- */

    public boolean deleteAdmin(String adminId) throws SQLException {
        String sql = "DELETE FROM Admin WHERE adminId = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, adminId);
            return ps.executeUpdate() > 0;
        }
    }

    /* ---------- HELPER ---------- */

    private AdminBean mapRow(ResultSet rs) throws SQLException {
        AdminBean admin = new AdminBean();
        admin.setAdminId(rs.getString("adminId"));
        admin.setAdminName(rs.getString("adminName"));
        admin.setAdminEmail(rs.getString("adminEmail"));
        admin.setAdminPassword(rs.getString("adminPassword"));
        admin.setCreatedAt(rs.getTimestamp("createdAt"));
        return admin;
    }
    
    /* ---------- DASHBOARD STATS ---------- */

    public int countRows(String tableName) throws SQLException {
        String sql = "SELECT COUNT(*) FROM " + tableName;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            rs.next();
            return rs.getInt(1);
        }
    }

    public double getTotalRevenue() throws SQLException {
        String sql = "SELECT SUM(amount) AS total FROM Transactions WHERE transactionStatus = 'Completed'";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                return rs.getDouble("total");
            }
        }
        return 0;
    }
}
