package dao;

import java.sql.*;
import java.util.*;
import rent.bean.TenantBean;
import util.DBConnection;

/**
 * Data Access Object for Tenant records.
 * Centralizes all SQL for the Tenant table so servlets stay thin.
 */
public class TenantDAO {

    /** Returns all tenants ordered by tenantId. */
    public List<TenantBean> getAllTenants() throws SQLException {
        List<TenantBean> tenantList = new ArrayList<>();
        String sql = "SELECT * FROM Tenant ORDER BY tenantId";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                tenantList.add(mapRow(rs));
            }
        }
        return tenantList;
    }

    /** Returns a single tenant by id, or null if not found. */
    public TenantBean getTenantById(String tenantId) throws SQLException {
        String sql = "SELECT * FROM Tenant WHERE tenantId = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, tenantId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    /** Inserts a new tenant. Assumes tenantId is already set on the bean. */
    public boolean addTenant(TenantBean tenant) throws SQLException {
        String sql = "INSERT INTO Tenant (tenantId, tenantName, phoneNumber, licenseNum, tenantEmail, tenantPassword) "
                   + "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, tenant.getTenantId());
            ps.setString(2, tenant.getTenantName());
            ps.setString(3, tenant.getPhoneNumber());
            ps.setString(4, tenant.getLicenseNum());
            ps.setString(5, tenant.getTenantEmail());
            ps.setString(6, tenant.getTenantPassword());
            return ps.executeUpdate() > 0;
        }
    }

    /** Updates an existing tenant's editable fields. */
    public boolean updateTenant(TenantBean tenant) throws SQLException {
        String sql = "UPDATE Tenant SET tenantName=?, phoneNumber=?, licenseNum=?, tenantEmail=? WHERE tenantId=?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, tenant.getTenantName());
            ps.setString(2, tenant.getPhoneNumber());
            ps.setString(3, tenant.getLicenseNum());
            ps.setString(4, tenant.getTenantEmail());
            ps.setString(5, tenant.getTenantId());
            return ps.executeUpdate() > 0;
        }
    }

    /** Returns true if the tenant has related RentDetails rows (i.e. cannot be safely deleted). */
    public boolean hasRentDetails(String tenantId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM RentDetails WHERE tenantId = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, tenantId);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1) > 0;
            }
        }
    }

    /**
     * Deletes a tenant by id.
     * Returns false without deleting if the tenant still has RentDetails rows.
     */
    public boolean deleteTenant(String tenantId) throws SQLException {
        if (hasRentDetails(tenantId)) {
            return false;
        }

        String sql = "DELETE FROM Tenant WHERE tenantId = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, tenantId);
            return ps.executeUpdate() > 0;
        }
    }

    /** Simple login check: returns the matching tenant, or null if credentials don't match. */
    public TenantBean authenticate(String tenantEmail, String tenantPassword) throws SQLException {
        String sql = "SELECT * FROM Tenant WHERE tenantEmail = ? AND tenantPassword = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, tenantEmail);
            ps.setString(2, tenantPassword);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    /** Maps the current row of a ResultSet to a TenantBean. */
    private TenantBean mapRow(ResultSet rs) throws SQLException {
        TenantBean tenant = new TenantBean();
        tenant.setTenantId(rs.getString("tenantId"));
        tenant.setTenantName(rs.getString("tenantName"));
        tenant.setPhoneNumber(rs.getString("phoneNumber"));
        tenant.setLicenseNum(rs.getString("licenseNum"));
        tenant.setTenantEmail(rs.getString("tenantEmail"));
        tenant.setCreatedAt(rs.getTimestamp("createdAt"));
        return tenant;
    }
}