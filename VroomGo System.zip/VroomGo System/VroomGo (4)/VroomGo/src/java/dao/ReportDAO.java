package dao;

import util.DBConnection;
import java.sql.*;
import java.util.*;

public class ReportDAO {

    // =========================================
    // Get Top Performing Owners
    // =========================================
    public List<Map<String, Object>> getTopOwners() {

        List<Map<String, Object>> topOwners = new ArrayList<>();

        String sql =
            "SELECT o.OWNERNAME, " +
            "COUNT(t.TRANSACTIONID) AS TOTALBOOKINGS, " +
            "SUM(t.OWNEREARNING) AS TOTALEARNED " +
            "FROM OWNER o " +
            "JOIN CAR c ON o.OWNERID = c.OWNERID " +
            "JOIN RENTDETAILS r ON c.CARID = r.CARID " +
            "JOIN TRANSACTIONS t ON r.RENTID = t.RENTID " +
            "WHERE t.TRANSACTIONSTATUS='Completed' " +
            "GROUP BY o.OWNERNAME " +
            "ORDER BY TOTALEARNED DESC";

        try (
            Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()
        ) {

            while (rs.next()) {

                Map<String, Object> row = new HashMap<>();

                row.put("ownerName", rs.getString("OWNERNAME"));
                row.put("totalBookings", rs.getInt("TOTALBOOKINGS"));
                row.put("totalEarned", rs.getDouble("TOTALEARNED"));

                topOwners.add(row);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return topOwners;
    }

    // =========================================
    // Get Most Rented Cars
    // =========================================
    public List<Map<String, Object>> getTopCars() {

        List<Map<String, Object>> topCars = new ArrayList<>();

        String sql =
            "SELECT c.CARMODEL, c.PLATENUMBER, " +
            "COUNT(r.RENTID) AS TIMESRENTED " +
            "FROM CAR c " +
            "JOIN RENTDETAILS r ON c.CARID = r.CARID " +
            "GROUP BY c.CARMODEL, c.PLATENUMBER " +
            "ORDER BY TIMESRENTED DESC";

        try (
            Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()
        ) {

            while (rs.next()) {

                Map<String, Object> row = new HashMap<>();

                row.put("carModel", rs.getString("CARMODEL"));
                row.put("plateNumber", rs.getString("PLATENUMBER"));
                row.put("timesRented", rs.getInt("TIMESRENTED"));

                topCars.add(row);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return topCars;
    }
    
// =========================================
// Get Total Revenue
// =========================================
public double getTotalRevenue() {

    double totalRevenue = 0.0;

    String sql =
        "SELECT SUM(AMOUNT) AS TOTALREVENUE " +
        "FROM TRANSACTIONS " +
        "WHERE TRANSACTIONSTATUS='Completed'";

    try (
        Connection conn = DBConnection.getConnection();
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery()
    ) {

        if (rs.next()) {
            totalRevenue = rs.getDouble("TOTALREVENUE");
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }

    return totalRevenue;
}

}