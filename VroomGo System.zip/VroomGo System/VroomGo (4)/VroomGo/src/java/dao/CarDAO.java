/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import rent.bean.CarBean;
import util.DBConnection;

/* Servlets should go through this class instead of writing JDBC directly */
public class CarDAO {

    /**
     * Generates the next unique carId in the format C001, C002, ...
     * Uses the given connection so it can participate in the same
     * transaction as the insert that follows it.
     */
    private String generateUniqueCarId(Connection conn) throws SQLException {
        String maxIdSql = "SELECT MAX(CAST(SUBSTR(carId, 2) AS INT)) AS maxId FROM Car";
        int nextNum = 1;
        try (PreparedStatement maxIdPs = conn.prepareStatement(maxIdSql);
             ResultSet maxIdRs = maxIdPs.executeQuery()) {
            if (maxIdRs.next()) {
                int currentMax = maxIdRs.getInt("maxId");
                if (!maxIdRs.wasNull()) {
                    nextNum = currentMax + 1;
                }
            }
        }

        String checkSql = "SELECT COUNT(*) FROM Car WHERE carId = ?";
        String candidateId = String.format("C%03d", nextNum);

        while (true) {
            try (PreparedStatement checkPs = conn.prepareStatement(checkSql)) {
                checkPs.setString(1, candidateId);
                try (ResultSet checkRs = checkPs.executeQuery()) {
                    checkRs.next();
                    if (checkRs.getInt(1) == 0) {
                        break;
                    }
                }
            }
            nextNum++;
            candidateId = String.format("C%03d", nextNum);
        }

        return candidateId;
    }

    /**
     * Inserts a new car, generating its carId. The generated id is set
     * back onto the passed-in CarBean so the caller can use it afterwards.
     */
    public String addCar(CarBean car) throws SQLException {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            String carId = generateUniqueCarId(conn);

            String sql = "INSERT INTO Car (carId, ownerId, plateNumber, carModel, carColour, rentalRate, carImage, status, createdAt) "
                       + "VALUES (?, ?, ?, ?, ?, ?, ?, 'Available', ?)";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, carId);
                ps.setString(2, car.getOwnerId());
                ps.setString(3, car.getPlateNumber());
                ps.setString(4, car.getCarModel());
                ps.setString(5, car.getCarColour());
                ps.setDouble(6, car.getRentalRate());
                ps.setString(7, car.getCarImage());
                ps.setTimestamp(8, new Timestamp(System.currentTimeMillis()));
                ps.executeUpdate();
            }

            car.setCarId(carId);
            return carId;
        } finally {
            DBConnection.closeConnection(conn);
        }
    }

    /**
     * Fetches a single car by id, or null if it doesn't exist.
     */
    public CarBean getCarById(String carId) throws SQLException {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            String sql = "SELECT * FROM Car WHERE carId = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, carId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        return mapRow(rs);
                    }
                }
            }
            return null;
        } finally {
            DBConnection.closeConnection(conn);
        }
    }

    /**
     * Returns every car that hasn't been soft-deleted, joined with its
     * owner's name, ordered by carId. Used by the admin "manage cars" view.
     */
    public List<CarBean> getAllCarsWithOwner() throws SQLException {
        Connection conn = null;
        List<CarBean> carList = new ArrayList<>();
        try {
            conn = DBConnection.getConnection();
            String sql = "SELECT c.*, o.ownerName FROM Car c JOIN Owner o ON c.ownerId = o.ownerId "
                       + "WHERE c.status != 'Deleted' ORDER BY c.carId";
            try (PreparedStatement ps = conn.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    CarBean car = mapRow(rs);
                    car.setOwnerName(rs.getString("ownerName"));
                    carList.add(car);
                }
            }
            return carList;
        } finally {
            DBConnection.closeConnection(conn);
        }
    }

    /**
     * Full update used by the owner's edit-car form (includes the image).
     */
    public boolean updateCarByOwner(CarBean car) throws SQLException {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            String sql = "UPDATE Car SET plateNumber=?, carModel=?, carColour=?, rentalRate=?, carImage=?, status=? WHERE carId=?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, car.getPlateNumber());
                ps.setString(2, car.getCarModel());
                ps.setString(3, car.getCarColour());
                ps.setDouble(4, car.getRentalRate());
                ps.setString(5, car.getCarImage());
                ps.setString(6, car.getStatus());
                ps.setString(7, car.getCarId());
                return ps.executeUpdate() > 0;
            }
        } finally {
            DBConnection.closeConnection(conn);
        }
    }

    /**
     * Update used by the admin's manage-cars form (no image field).
     */
    public boolean updateCarByAdmin(CarBean car) throws SQLException {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            String sql = "UPDATE Car SET plateNumber=?, carModel=?, carColour=?, rentalRate=?, status=? WHERE carId=?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, car.getPlateNumber());
                ps.setString(2, car.getCarModel());
                ps.setString(3, car.getCarColour());
                ps.setDouble(4, car.getRentalRate());
                ps.setString(5, car.getStatus());
                ps.setString(6, car.getCarId());
                return ps.executeUpdate() > 0;
            }
        } finally {
            DBConnection.closeConnection(conn);
        }
    }

    /**
     * Returns the current status of a car, or null if it doesn't exist.
     */
    public String getCarStatus(String carId) throws SQLException {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            String sql = "SELECT status FROM Car WHERE carId = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, carId);
                try (ResultSet rs = ps.executeQuery()) {
                    return rs.next() ? rs.getString("status") : null;
                }
            }
        } finally {
            DBConnection.closeConnection(conn);
        }
    }

    /**
     * Soft-deletes a car by marking its status as 'Deleted'.
     * Returns false (without deleting) if the car is currently Rented.
     */
    public boolean softDeleteCar(String carId) throws SQLException {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();

            String checkSql = "SELECT status FROM Car WHERE carId = ?";
            try (PreparedStatement checkPs = conn.prepareStatement(checkSql)) {
                checkPs.setString(1, carId);
                try (ResultSet rs = checkPs.executeQuery()) {
                    if (rs.next() && "Rented".equals(rs.getString("status"))) {
                        return false;
                    }
                }
            }

            String sql = "UPDATE Car SET status = 'Deleted' WHERE carId = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, carId);
                ps.executeUpdate();
            }
            return true;
        } finally {
            DBConnection.closeConnection(conn);
        }
    }

    private CarBean mapRow(ResultSet rs) throws SQLException {
        CarBean car = new CarBean();
        car.setCarId(rs.getString("carId"));
        car.setOwnerId(rs.getString("ownerId"));
        car.setPlateNumber(rs.getString("plateNumber"));
        car.setCarModel(rs.getString("carModel"));
        car.setCarColour(rs.getString("carColour"));
        car.setRentalRate(rs.getDouble("rentalRate"));
        car.setCarImage(rs.getString("carImage"));
        car.setStatus(rs.getString("status"));
        return car;
    }
    
    public List<CarBean> getCarsByOwner(String ownerId) {
        List<CarBean> carList = new ArrayList<>();
        String sql = "SELECT * FROM Car WHERE ownerId = ? AND status != 'Deleted'";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, ownerId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    CarBean car = new CarBean();
                    car.setCarId(rs.getString("carId"));
                    car.setPlateNumber(rs.getString("plateNumber"));
                    car.setCarModel(rs.getString("carModel"));
                    car.setCarColour(rs.getString("carColour"));
                    car.setRentalRate(rs.getDouble("rentalRate"));
                    car.setStatus(rs.getString("status"));
                    carList.add(car);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return carList;
    }
    
    public double getOwnerEarnings(String ownerId) {
        String sql = "SELECT SUM(COALESCE(t.ownerEarning, t.amount * 0.9)) AS totalEarnings " +
                     "FROM Transactions t " +
                     "JOIN RentDetails r ON t.rentId = r.rentId " +
                     "JOIN Car c ON r.carId = c.carId " +
                     "WHERE c.ownerId = ? AND t.transactionStatus = 'Completed'";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, ownerId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getDouble("totalEarnings");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0.0;
    }
    
    
}