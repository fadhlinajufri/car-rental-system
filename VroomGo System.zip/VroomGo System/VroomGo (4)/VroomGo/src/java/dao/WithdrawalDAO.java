/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import rent.bean.WithdrawalBean;
import util.DBConnection;

/* Servlets should go through this class instead of writing JDBC directly */
public class WithdrawalDAO {

    /**
     * Amount an owner has available to withdraw: total earnings minus
     * anything already Paid, and minus anything currently Pending/Approved
     * (so they can't request the same money twice while a request is open).
     */
    public double getAvailableBalance(String ownerId) throws SQLException {
        CarDAO carDAO = new CarDAO();
        double totalEarnings = carDAO.getOwnerEarnings(ownerId);

        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            String sql = "SELECT COALESCE(SUM(amount), 0) AS reserved FROM Withdrawal "
                       + "WHERE ownerId = ? AND status IN ('Pending', 'Approved', 'Paid')";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, ownerId);
                try (ResultSet rs = ps.executeQuery()) {
                    double reserved = rs.next() ? rs.getDouble("reserved") : 0;
                    return totalEarnings - reserved;
                }
            }
        } finally {
            DBConnection.closeConnection(conn);
        }
    }

    /**
     * Creates a new Pending withdrawal request, after re-checking the
     * requested amount against the owner's current available balance.
     * Returns the generated withdrawId, or null if the amount exceeds
     * what's available.
     */
    public String requestWithdrawal(String ownerId, double amount) throws SQLException {
        if (amount <= 0 || amount > getAvailableBalance(ownerId)) {
            return null;
        }

        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            String withdrawId = generateUniqueWithdrawId(conn);

            String sql = "INSERT INTO Withdrawal (withdrawId, ownerId, amount, status, requestDate) "
                       + "VALUES (?, ?, ?, 'Pending', ?)";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, withdrawId);
                ps.setString(2, ownerId);
                ps.setDouble(3, amount);
                ps.setTimestamp(4, new Timestamp(System.currentTimeMillis()));
                ps.executeUpdate();
            }
            return withdrawId;
        } finally {
            DBConnection.closeConnection(conn);
        }
    }

    /** Returns an owner's withdrawal history, most recent first. */
    public List<WithdrawalBean> getWithdrawalsByOwner(String ownerId) throws SQLException {
        Connection conn = null;
        List<WithdrawalBean> list = new ArrayList<>();
        try {
            conn = DBConnection.getConnection();
            String sql = "SELECT * FROM Withdrawal WHERE ownerId = ? ORDER BY requestDate DESC";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, ownerId);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        list.add(mapRow(rs));
                    }
                }
            }
            return list;
        } finally {
            DBConnection.closeConnection(conn);
        }
    }

    /**
     * Returns all withdrawal requests joined with owner name + bank details,
     * for the admin screen. Most recent first.
     */
    public List<WithdrawalBean> getAllWithdrawalsWithOwnerInfo() throws SQLException {
        Connection conn = null;
        List<WithdrawalBean> list = new ArrayList<>();
        try {
            conn = DBConnection.getConnection();
            String sql = "SELECT w.*, o.ownerName, o.bankName, o.bankAccNumber "
                       + "FROM Withdrawal w JOIN Owner o ON w.ownerId = o.ownerId "
                       + "ORDER BY w.requestDate DESC";
            try (PreparedStatement ps = conn.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    WithdrawalBean w = mapRow(rs);
                    w.setOwnerName(rs.getString("ownerName"));
                    w.setBankName(rs.getString("bankName"));
                    w.setBankAccNumber(rs.getString("bankAccNumber"));
                    list.add(w);
                }
            }
            return list;
        } finally {
            DBConnection.closeConnection(conn);
        }
    }

    /** Admin approves a Pending request. */
    public boolean approve(String withdrawId) throws SQLException {
        return updateStatus(withdrawId, "Pending", "Approved", null);
    }

    /** Admin declines a Pending request, with a reason shown to the owner. */
    public boolean decline(String withdrawId, String remarks) throws SQLException {
        return updateStatus(withdrawId, "Pending", "Declined", remarks);
    }

    /** Admin marks an Approved request as Paid, after making the bank transfer manually. */
    public boolean markAsPaid(String withdrawId) throws SQLException {
        return updateStatus(withdrawId, "Approved", "Paid", null);
    }

    /**
     * Moves a withdrawal from fromStatus to toStatus, stamping processedDate.
     * Only takes effect if the row is currently in fromStatus, so requests
     * can't be double-processed by two admin clicks.
     */
    private boolean updateStatus(String withdrawId, String fromStatus, String toStatus, String remarks) throws SQLException {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            String sql = "UPDATE Withdrawal SET status = ?, processedDate = ?, remarks = ? "
                       + "WHERE withdrawId = ? AND status = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, toStatus);
                ps.setTimestamp(2, new Timestamp(System.currentTimeMillis()));
                ps.setString(3, remarks);
                ps.setString(4, withdrawId);
                ps.setString(5, fromStatus);
                return ps.executeUpdate() > 0;
            }
        } finally {
            DBConnection.closeConnection(conn);
        }
    }

    private String generateUniqueWithdrawId(Connection conn) throws SQLException {
        String maxIdSql = "SELECT MAX(CAST(SUBSTR(withdrawId, 2) AS INT)) AS maxId FROM Withdrawal";
        int nextNum = 1;
        try (PreparedStatement maxIdPs = conn.prepareStatement(maxIdSql);
             ResultSet maxIdRs = maxIdPs.executeQuery()) {
            if (maxIdRs.next()) {
                int currentMax = maxIdRs.getInt("maxId");
                if (!maxIdRs.wasNull()) {
                    nextNum = currentMax + 1;
                }
            }
        }

        String checkSql = "SELECT COUNT(*) FROM Withdrawal WHERE withdrawId = ?";
        String candidateId = String.format("W%03d", nextNum);
        while (true) {
            try (PreparedStatement checkPs = conn.prepareStatement(checkSql)) {
                checkPs.setString(1, candidateId);
                try (ResultSet checkRs = checkPs.executeQuery()) {
                    checkRs.next();
                    if (checkRs.getInt(1) == 0) break;
                }
            }
            nextNum++;
            candidateId = String.format("W%03d", nextNum);
        }
        return candidateId;
    }

    private WithdrawalBean mapRow(ResultSet rs) throws SQLException {
        WithdrawalBean w = new WithdrawalBean();
        w.setWithdrawId(rs.getString("withdrawId"));
        w.setOwnerId(rs.getString("ownerId"));
        w.setAmount(rs.getDouble("amount"));
        w.setStatus(rs.getString("status"));
        w.setRequestDate(rs.getTimestamp("requestDate"));
        w.setProcessedDate(rs.getTimestamp("processedDate"));
        w.setRemarks(rs.getString("remarks"));
        return w;
    }
}