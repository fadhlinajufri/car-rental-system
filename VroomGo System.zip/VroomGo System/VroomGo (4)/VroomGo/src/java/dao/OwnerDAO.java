/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package dao;

import rent.bean.OwnerBean;
import util.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class OwnerDAO {

    public OwnerBean login(String email, String password) {
        String sql = "SELECT * FROM Owner WHERE ownerEmail = ? AND ownerPassword = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            ps.setString(2, password);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean register(OwnerBean owner) throws SQLException {
        String sql = "INSERT INTO Owner (ownerId, ownerName, phoneNumber, ownerEmail, ownerPassword, createdAt) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection()) {
            String ownerId = generateUniqueOwnerId(conn);
            owner.setOwnerId(ownerId);
            
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, owner.getOwnerId());
                ps.setString(2, owner.getOwnerName());
                ps.setString(3, owner.getPhoneNumber());
                ps.setString(4, owner.getOwnerEmail());
                ps.setString(5, owner.getOwnerPassword());
                ps.setTimestamp(6, new Timestamp(System.currentTimeMillis()));
                return ps.executeUpdate() > 0;
            }
        }
    }

    public boolean isDuplicate(String columnName, String value) {
        String sql = "SELECT 1 FROM Owner WHERE " + columnName + " = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, value);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean isEmailDuplicateForOther(String email, String ownerId) {
        String sql = "SELECT 1 FROM Owner WHERE ownerEmail = ? AND ownerId != ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            ps.setString(2, ownerId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public OwnerBean getOwnerById(String ownerId) {
        String sql = "SELECT * FROM Owner WHERE ownerId = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, ownerId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Updates name/phone/email/password plus bank details (bankName,
     * bankAccNumber) used for payment withdrawals.
     */
    public boolean updateProfile(OwnerBean owner) {
        String sql = "UPDATE Owner SET ownerName = ?, phoneNumber = ?, ownerEmail = ?, ownerPassword = ?, "
                   + "bankName = ?, bankAccNumber = ? WHERE ownerId = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, owner.getOwnerName());
            ps.setString(2, owner.getPhoneNumber());
            ps.setString(3, owner.getOwnerEmail());
            ps.setString(4, owner.getOwnerPassword());
            ps.setString(5, owner.getBankName());
            ps.setString(6, owner.getBankAccNumber());
            ps.setString(7, owner.getOwnerId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private String generateUniqueOwnerId(Connection conn) throws SQLException {
        String maxIdSql = "SELECT MAX(CAST(SUBSTR(ownerId, 2) AS INT)) AS maxId FROM Owner";
        int nextNum = 1;
        try (PreparedStatement maxIdPs = conn.prepareStatement(maxIdSql);
             ResultSet maxIdRs = maxIdPs.executeQuery()) {
            if (maxIdRs.next()) {
                int currentMax = maxIdRs.getInt("maxId");
                if (!maxIdRs.wasNull()) {
                    nextNum = currentMax + 1;
                }
            }
        }
        String checkSql = "SELECT COUNT(*) FROM Owner WHERE ownerId = ?";
        String candidateId = String.format("O%03d", nextNum);
        while (true) {
            try (PreparedStatement checkPs = conn.prepareStatement(checkSql)) {
                checkPs.setString(1, candidateId);
                try (ResultSet checkRs = checkPs.executeQuery()) {
                    checkRs.next();
                    if (checkRs.getInt(1) == 0) break;
                }
            }
            nextNum++;
            candidateId = String.format("O%03d", nextNum);
        }
        return candidateId;
    }

    private OwnerBean mapRow(ResultSet rs) throws SQLException {
        OwnerBean owner = new OwnerBean();
        owner.setOwnerId(rs.getString("ownerId"));
        owner.setOwnerName(rs.getString("ownerName"));
        owner.setPhoneNumber(rs.getString("phoneNumber"));
        owner.setOwnerEmail(rs.getString("ownerEmail"));
        owner.setOwnerPassword(rs.getString("ownerPassword"));
        owner.setBankName(rs.getString("bankName"));
        owner.setBankAccNumber(rs.getString("bankAccNumber"));
        return owner;
    }
}